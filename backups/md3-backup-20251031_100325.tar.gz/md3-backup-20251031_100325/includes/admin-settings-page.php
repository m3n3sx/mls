<?php
/**
 * Admin Settings Page Template - MASE v1.2.0
 *
 * 8-tab structure with comprehensive customization options:
 * - General: Palettes, Templates, Master Controls
 * - Admin Bar: Colors, Typography, Visual Effects
 * - Menu: Colors, Typography, Visual Effects
 * - Content: Background, Spacing, Layout
 * - Typography: Font controls for all areas
 * - Effects: Animations, Hover, Visual Effects
 * - Templates: Full template gallery
 * - Advanced: Custom CSS/JS, Auto Palette, Backup
 *
 * @package ModernAdminStyler
 * @since 1.2.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

// Get settings instance
$settings_obj = new MASE_Settings();
$settings     = $settings_obj->get_option();
$palettes     = $settings_obj->get_all_palettes();
$templates    = $settings_obj->get_all_templates();
?>

<div class="wrap mase-settings-wrap" 
	data-mase-version="<?php echo esc_attr( MASE_VERSION ); ?>"
	data-mase-rest-url="<?php echo esc_attr( rest_url( 'mase/v1' ) ); ?>"
	data-mase-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>">
	
	<!-- Loading State Container (Requirement 10.1) -->
	<div id="mase-loading-overlay" class="mase-loading-overlay" style="display: none;" role="status" aria-live="polite">
		<div class="mase-loading-spinner">
			<span class="dashicons dashicons-update" aria-hidden="true"></span>
			<span class="mase-loading-text"><?php esc_html_e( 'Loading...', 'modern-admin-styler' ); ?></span>
		</div>
	</div>
	
	<!-- Error Boundary Container (Requirement 10.1) -->
	<div id="mase-error-boundary" class="mase-error-boundary" style="display: none;" role="alert" aria-live="assertive">
		<div class="mase-error-content">
			<span class="dashicons dashicons-warning" aria-hidden="true"></span>
			<h3><?php esc_html_e( 'Something went wrong', 'modern-admin-styler' ); ?></h3>
			<p class="mase-error-message"></p>
			<button type="button" class="button button-primary mase-error-reload">
				<?php esc_html_e( 'Reload Page', 'modern-admin-styler' ); ?>
			</button>
		</div>
	</div>
	
	<!-- ARIA Live Region for Dynamic Notices (Requirement 13.5) -->
	<div id="mase-notice-region" class="mase-notice-region" role="status" aria-live="polite" aria-atomic="true"></div>
	
	<!-- Header Section (MD3 Artistic Header - Requirements 5.1, 5.3) -->
	<div class="mase-header mase-md3-header">
		<!-- Floating Orb Animation Container -->
		<div class="mase-header-orb" aria-hidden="true"></div>
		
		<div class="mase-header-content">
			<div class="mase-header-left">
				<h1 class="mase-admin-title">
					<?php echo esc_html( get_admin_page_title() ); ?>
					<span class="mase-version-badge">v1.2.0</span>
				</h1>
				<p class="mase-admin-subtitle"><?php esc_html_e( 'Transform your WordPress admin with modern design and powerful customization', 'modern-admin-styler' ); ?></p>
			</div>
			<div class="mase-header-right">
				<!-- Dark Mode Toggle -->
				<label class="mase-header-toggle">
					<input 
						type="checkbox" 
						id="mase-dark-mode-toggle"
						name="mase_dark_mode" 
						value="1"
						<?php checked( $settings['master']['dark_mode'] ?? false, true ); ?>
						role="switch"
						aria-checked="<?php echo ( $settings['master']['dark_mode'] ?? false ) ? 'true' : 'false'; ?>"
						aria-label="<?php esc_attr_e( 'Toggle dark mode for entire admin', 'modern-admin-styler' ); ?>"
					/>
					<span class="dashicons dashicons-admin-appearance" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Dark Mode', 'modern-admin-styler' ); ?></span>
				</label>
				<label class="mase-header-toggle">
					<?php
					// Get live preview setting, default to true (enabled by default)
					// @see Task 11.4 in .kiro/specs/critical-fixes-v1.2.0/tasks.md
					$live_preview_enabled = isset( $settings['master']['live_preview'] )
						? (bool) $settings['master']['live_preview']
						: true;
					?>
					<input 
						type="checkbox" 
						id="mase-live-preview-toggle"
						name="mase_live_preview" 
						value="1"
						<?php checked( $live_preview_enabled, true ); ?>
						role="switch"
						aria-checked="<?php echo esc_attr( $live_preview_enabled ? 'true' : 'false' ); ?>"
						aria-label="<?php esc_attr_e( 'Toggle live preview mode', 'modern-admin-styler' ); ?>"
					/>
					<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Live Preview', 'modern-admin-styler' ); ?></span>
				</label>
				<button type="button" id="mase-reset-all" class="button button-secondary" aria-label="<?php esc_attr_e( 'Reset all settings to default values', 'modern-admin-styler' ); ?>">
					<span class="dashicons dashicons-image-rotate" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Reset All', 'modern-admin-styler' ); ?></span>
				</button>
				<button type="submit" form="mase-settings-form" id="mase-save-settings" class="button button-primary" aria-label="<?php esc_attr_e( 'Save all settings', 'modern-admin-styler' ); ?>">
					<span class="dashicons dashicons-saved" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Save Settings', 'modern-admin-styler' ); ?></span>
				</button>
			</div>
		</div>
	</div>

	<!-- Tab Navigation - MD3 Design (Requirements 6.1, 13.4: Keyboard accessible) -->
	<div class="mase-tab-nav-container">
		<nav class="mase-tab-nav mase-md3-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Settings navigation', 'modern-admin-styler' ); ?>">
			<button type="button" class="mase-tab-button mase-md3-tab active" data-tab="general" role="tab" aria-selected="true" aria-controls="tab-general" id="tab-button-general" tabindex="0">
				<span class="mase-tab-icon dashicons dashicons-admin-home" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'General', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="admin-bar" role="tab" aria-selected="false" aria-controls="tab-admin-bar" id="tab-button-admin-bar" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-admin-generic" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Admin Bar', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="menu" role="tab" aria-selected="false" aria-controls="tab-menu" id="tab-button-menu" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-menu" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Menu', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="content" role="tab" aria-selected="false" aria-controls="tab-content" id="tab-button-content" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-layout" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Content', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="typography" role="tab" aria-selected="false" aria-controls="tab-typography" id="tab-button-typography" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-editor-textcolor" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Typography', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="widgets" role="tab" aria-selected="false" aria-controls="tab-widgets" id="tab-button-widgets" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-welcome-widgets-menus" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Dashboard Widgets', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="form-controls" role="tab" aria-selected="false" aria-controls="tab-form-controls" id="tab-button-form-controls" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-edit" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Form Controls', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="effects" role="tab" aria-selected="false" aria-controls="tab-effects" id="tab-button-effects" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-art" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Effects', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="buttons" role="tab" aria-selected="false" aria-controls="tab-buttons" id="tab-button-buttons" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-editor-bold" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Universal Buttons', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="backgrounds" role="tab" aria-selected="false" aria-controls="tab-backgrounds" id="tab-button-backgrounds" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-format-image" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Backgrounds', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="templates" role="tab" aria-selected="false" aria-controls="tab-templates" id="tab-button-templates" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-portfolio" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Templates', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="login" role="tab" aria-selected="false" aria-controls="tab-login" id="tab-button-login" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-lock" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Login Page', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
			<button type="button" class="mase-tab-button mase-md3-tab" data-tab="advanced" role="tab" aria-selected="false" aria-controls="tab-advanced" id="tab-button-advanced" tabindex="-1">
				<span class="mase-tab-icon dashicons dashicons-admin-tools" aria-hidden="true"></span>
				<span class="mase-tab-label"><?php esc_html_e( 'Advanced', 'modern-admin-styler' ); ?></span>
				<span class="mase-tab-indicator" aria-hidden="true"></span>
			</button>
		</nav>
	</div>

	<!-- Main Form -->
	<form id="mase-settings-form" method="post" action="" aria-label="<?php esc_attr_e( 'Modern Admin Styler settings form', 'modern-admin-styler' ); ?>">
		<?php wp_nonce_field( 'mase_save_settings', 'mase_nonce' ); ?>
		
		<!-- Tab Content Container -->
		<div class="mase-tab-content-wrapper" id="mase-main-content">
			
			<!-- ============================================ -->
			<!-- GENERAL TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content active" id="tab-general" data-tab-content="general" role="tabpanel" aria-labelledby="tab-button-general" tabindex="0">
				
				<!-- Color Palettes Section -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Color Palettes', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Choose from 10 professionally designed color schemes. Click to preview, Apply to activate.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<div class="mase-palette-grid" role="group" aria-label="<?php esc_attr_e( 'Color palettes', 'modern-admin-styler' ); ?>">
						<?php foreach ( $palettes as $palette_id => $palette ) : ?>
							<div class="mase-palette-card <?php echo ( $settings['palettes']['current'] === $palette_id ) ? 'active' : ''; ?>" data-palette="<?php echo esc_attr( $palette_id ); ?>" data-palette-id="<?php echo esc_attr( $palette_id ); ?>" role="button" tabindex="0" aria-label="<?php echo esc_attr( sprintf( __( 'Apply %s palette', 'modern-admin-styler' ), $palette['name'] ) ); ?>">
								<div class="mase-palette-preview" role="img" aria-label="<?php echo esc_attr( sprintf( __( 'Color preview for %s palette', 'modern-admin-styler' ), $palette['name'] ) ); ?>">
									<span class="mase-palette-color" style="background-color: <?php echo esc_attr( $palette['colors']['primary'] ); ?>" aria-label="<?php esc_attr_e( 'Primary color', 'modern-admin-styler' ); ?>"></span>
									<span class="mase-palette-color" style="background-color: <?php echo esc_attr( $palette['colors']['secondary'] ); ?>" aria-label="<?php esc_attr_e( 'Secondary color', 'modern-admin-styler' ); ?>"></span>
									<span class="mase-palette-color" style="background-color: <?php echo esc_attr( $palette['colors']['accent'] ); ?>" aria-label="<?php esc_attr_e( 'Accent color', 'modern-admin-styler' ); ?>"></span>
									<span class="mase-palette-color" style="background-color: <?php echo esc_attr( $palette['colors']['background'] ); ?>" aria-label="<?php esc_attr_e( 'Background color', 'modern-admin-styler' ); ?>"></span>
								</div>
								<div class="mase-palette-info">
									<h3 class="mase-palette-name"><?php echo esc_html( $palette['name'] ); ?></h3>
									<?php if ( $settings['palettes']['current'] === $palette_id ) : ?>
										<span class="mase-active-badge" role="status"><?php esc_html_e( 'Active', 'modern-admin-styler' ); ?></span>
									<?php endif; ?>
								</div>
								<div class="mase-palette-actions">
									<button type="button" class="button button-secondary mase-palette-preview-btn" data-palette-id="<?php echo esc_attr( $palette_id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Preview %s palette', 'modern-admin-styler' ), $palette['name'] ) ); ?>">
										<?php esc_html_e( 'Preview', 'modern-admin-styler' ); ?>
									</button>
									<button type="button" class="button button-primary mase-palette-apply-btn" data-palette-id="<?php echo esc_attr( $palette_id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Apply %s palette', 'modern-admin-styler' ), $palette['name'] ) ); ?>">
										<?php esc_html_e( 'Apply', 'modern-admin-styler' ); ?>
									</button>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>

				<!-- Template Preview Section -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Quick Templates', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Preview of 3 popular templates. View all templates in the Templates tab.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<div class="mase-template-preview-grid">
						<?php
						$preview_templates = array_slice( $templates, 0, 3, true );
						foreach ( $preview_templates as $template_id => $template ) :
							?>
							<div class="mase-template-preview-card <?php echo ( $settings['templates']['current'] === $template_id ) ? 'active' : ''; ?>" data-template="<?php echo esc_attr( $template_id ); ?>" data-template-id="<?php echo esc_attr( $template_id ); ?>">
								<div class="mase-template-thumbnail">
									<?php if ( ! empty( $template['thumbnail'] ) ) : ?>
										<img src="<?php echo esc_attr( $template['thumbnail'] ); ?>" alt="<?php echo esc_attr( $template['name'] ); ?>" />
									<?php else : ?>
										<div class="mase-template-placeholder">
											<span class="dashicons dashicons-admin-appearance"></span>
										</div>
									<?php endif; ?>
									<?php if ( $settings['templates']['current'] === $template_id ) : ?>
										<span class="mase-active-badge"><?php esc_html_e( 'Active', 'modern-admin-styler' ); ?></span>
									<?php endif; ?>
								</div>
								<div class="mase-template-info">
									<h3><?php echo esc_html( $template['name'] ); ?></h3>
									<p class="description"><?php echo esc_html( $template['description'] ); ?></p>
								</div>
								<div class="mase-template-actions">
									<button type="button" class="button mase-template-customize-btn" data-template-id="<?php echo esc_attr( $template_id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Customize %s template', 'modern-admin-styler' ), $template['name'] ) ); ?>">
										<span class="dashicons dashicons-admin-customizer"></span>
										<?php esc_html_e( 'Customize', 'modern-admin-styler' ); ?>
									</button>
									<button type="button" class="button button-primary mase-template-apply-btn" data-template-id="<?php echo esc_attr( $template_id ); ?>">
										<?php esc_html_e( 'Apply Template', 'modern-admin-styler' ); ?>
									</button>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
					
					<div class="mase-view-all-templates">
						<button type="button" class="button button-secondary" data-switch-tab="templates">
							<?php esc_html_e( 'View All Templates', 'modern-admin-styler' ); ?>
							<span class="dashicons dashicons-arrow-right-alt2"></span>
						</button>
					</div>
				</div>

				<!-- Master Controls Section -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Master Controls', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Global settings that affect the entire admin interface.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="master-enable-plugin">
										<?php esc_html_e( 'Enable Plugin', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="master-enable-plugin"
											name="master[enabled]" 
											value="1"
											<?php checked( $settings['master']['enabled'] ?? true, true ); ?>
											aria-describedby="master-enable-plugin-desc"
											role="switch"
											aria-checked="<?php echo ( $settings['master']['enabled'] ?? true ) ? 'true' : 'false'; ?>"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="master-enable-plugin-desc"><?php esc_html_e( 'Turn off to temporarily disable all customizations without losing your settings.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="master-apply-to-login">
										<?php esc_html_e( 'Apply to Login Page', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="master-apply-to-login"
											name="master[apply_to_login]" 
											value="1"
											<?php checked( $settings['master']['apply_to_login'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['master']['apply_to_login'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="master-apply-to-login-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="master-apply-to-login-desc"><?php esc_html_e( 'Apply your color scheme to the WordPress login page.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="master-dark-mode">
										<?php esc_html_e( 'Dark Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="master-dark-mode"
											name="master[dark_mode]" 
											value="1"
											<?php checked( $settings['master']['dark_mode'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['master']['dark_mode'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="master-dark-mode-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="master-dark-mode-desc"><?php esc_html_e( 'Enable dark mode for the admin interface.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div><!-- #tab-general -->


			<!-- ============================================ -->
			<!-- ADMIN BAR TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-admin-bar" data-tab-content="admin-bar" role="tabpanel" aria-labelledby="tab-button-admin-bar" tabindex="0">
				
				<!-- Admin Bar Colors -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Admin Bar Colors', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the colors of the WordPress admin bar.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-bg-color">
										<?php esc_html_e( 'Background Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-bar-bg-color"
										name="admin_bar[bg_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_bar']['bg_color'] ); ?>"
										data-default-color="#23282d"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-text-color">
										<?php esc_html_e( 'Text Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-bar-text-color"
										name="admin_bar[text_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_bar']['text_color'] ); ?>"
										data-default-color="#ffffff"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-hover-color">
										<?php esc_html_e( 'Hover Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-bar-hover-color"
										name="admin_bar[hover_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_bar']['hover_color'] ?? '#0073aa' ); ?>"
										data-default-color="#0073aa"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-height">
										<?php esc_html_e( 'Height (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="number" 
										id="admin-bar-height"
										name="admin_bar[height]" 
										class="small-text"
										value="<?php echo esc_attr( $settings['admin_bar']['height'] ); ?>"
										min="32"
										max="100"
										step="1"
									/>
									<p class="description"><?php esc_html_e( 'Default: 32px. Range: 32-100px.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Admin Bar Gradient Background (Requirements 5.1, 5.2, 5.3, 5.4, 5.5) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Background Gradient', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Apply gradient backgrounds to the admin bar.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-bg-type">
										<?php esc_html_e( 'Background Type', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-bg-type" name="admin_bar[bg_type]">
										<option value="solid" <?php selected( $settings['admin_bar']['bg_type'] ?? 'solid', 'solid' ); ?>>
											<?php esc_html_e( 'Solid Color', 'modern-admin-styler' ); ?>
										</option>
										<option value="gradient" <?php selected( $settings['admin_bar']['bg_type'] ?? 'solid', 'gradient' ); ?>>
											<?php esc_html_e( 'Gradient', 'modern-admin-styler' ); ?>
										</option>
									</select>
								</div>
							</div>
							
							<!-- Gradient Controls (shown when bg_type = gradient) -->
							<div class="mase-conditional-group" data-depends-on="admin-bar-bg-type" data-value="gradient" style="display: <?php echo ( isset( $settings['admin_bar']['bg_type'] ) && $settings['admin_bar']['bg_type'] === 'gradient' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-gradient-type">
											<?php esc_html_e( 'Gradient Type', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<select id="admin-bar-gradient-type" name="admin_bar[gradient_type]">
											<option value="linear" <?php selected( $settings['admin_bar']['gradient_type'] ?? 'linear', 'linear' ); ?>>
												<?php esc_html_e( 'Linear', 'modern-admin-styler' ); ?>
											</option>
											<option value="radial" <?php selected( $settings['admin_bar']['gradient_type'] ?? 'linear', 'radial' ); ?>>
												<?php esc_html_e( 'Radial', 'modern-admin-styler' ); ?>
											</option>
											<option value="conic" <?php selected( $settings['admin_bar']['gradient_type'] ?? 'linear', 'conic' ); ?>>
												<?php esc_html_e( 'Conic', 'modern-admin-styler' ); ?>
											</option>
										</select>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-gradient-angle">
											<?php esc_html_e( 'Angle (degrees)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-gradient-angle"
											name="admin_bar[gradient_angle]" 
											min="0"
											max="360"
											step="1"
											value="<?php echo esc_attr( $settings['admin_bar']['gradient_angle'] ?? 90 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['gradient_angle'] ?? 90 ); ?>°</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-gradient-color-1">
											<?php esc_html_e( 'Color Stop 1', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="admin-bar-gradient-color-1"
											name="admin_bar[gradient_colors][0][color]" 
											class="mase-color-picker"
											value="<?php echo esc_attr( $settings['admin_bar']['gradient_colors'][0]['color'] ?? '#23282d' ); ?>"
											data-default-color="#23282d"
										/>
										<input 
											type="hidden" 
											name="admin_bar[gradient_colors][0][position]" 
											value="0"
										/>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-gradient-color-2">
											<?php esc_html_e( 'Color Stop 2', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="admin-bar-gradient-color-2"
											name="admin_bar[gradient_colors][1][color]" 
											class="mase-color-picker"
											value="<?php echo esc_attr( $settings['admin_bar']['gradient_colors'][1]['color'] ?? '#32373c' ); ?>"
											data-default-color="#32373c"
										/>
										<input 
											type="hidden" 
											name="admin_bar[gradient_colors][1][position]" 
											value="100"
										/>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Admin Bar Typography -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Admin Bar Typography', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the typography of the admin bar.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-font-size">
										<?php esc_html_e( 'Font Size (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="number" 
										id="admin-bar-font-size"
										name="typography[admin_bar][font_size]" 
										class="small-text"
										value="<?php echo esc_attr( $settings['typography']['admin_bar']['font_size'] ); ?>"
										min="10"
										max="24"
										step="1"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-font-weight">
										<?php esc_html_e( 'Font Weight', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-font-weight" name="typography[admin_bar][font_weight]">
										<option value="300" <?php selected( $settings['typography']['admin_bar']['font_weight'], 300 ); ?>>300 (Light)</option>
										<option value="400" <?php selected( $settings['typography']['admin_bar']['font_weight'], 400 ); ?>>400 (Normal)</option>
										<option value="500" <?php selected( $settings['typography']['admin_bar']['font_weight'], 500 ); ?>>500 (Medium)</option>
										<option value="600" <?php selected( $settings['typography']['admin_bar']['font_weight'], 600 ); ?>>600 (Semi-Bold)</option>
										<option value="700" <?php selected( $settings['typography']['admin_bar']['font_weight'], 700 ); ?>>700 (Bold)</option>
									</select>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-line-height">
										<?php esc_html_e( 'Line Height', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-line-height"
										name="typography[admin_bar][line_height]" 
										value="<?php echo esc_attr( $settings['typography']['admin_bar']['line_height'] ); ?>"
										min="1.0"
										max="2.0"
										step="0.1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['typography']['admin_bar']['line_height'] ); ?></span>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-letter-spacing">
										<?php esc_html_e( 'Letter Spacing (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-letter-spacing"
										name="typography[admin_bar][letter_spacing]" 
										value="<?php echo esc_attr( $settings['typography']['admin_bar']['letter_spacing'] ?? 0 ); ?>"
										min="-2"
										max="5"
										step="0.5"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['typography']['admin_bar']['letter_spacing'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-text-transform">
										<?php esc_html_e( 'Text Transform', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-text-transform" name="typography[admin_bar][text_transform]">
										<option value="none" <?php selected( $settings['typography']['admin_bar']['text_transform'] ?? 'none', 'none' ); ?>><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
										<option value="uppercase" <?php selected( $settings['typography']['admin_bar']['text_transform'] ?? 'none', 'uppercase' ); ?>><?php esc_html_e( 'Uppercase', 'modern-admin-styler' ); ?></option>
										<option value="lowercase" <?php selected( $settings['typography']['admin_bar']['text_transform'] ?? 'none', 'lowercase' ); ?>><?php esc_html_e( 'Lowercase', 'modern-admin-styler' ); ?></option>
										<option value="capitalize" <?php selected( $settings['typography']['admin_bar']['text_transform'] ?? 'none', 'capitalize' ); ?>><?php esc_html_e( 'Capitalize', 'modern-admin-styler' ); ?></option>
									</select>
								</div>
							</div>
							
							<!-- NEW: Font Family Selector (Requirement 8.1, 8.4) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-font-family">
										<?php esc_html_e( 'Font Family', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-font-family" name="typography[admin_bar][font_family]">
										<optgroup label="<?php esc_attr_e( 'System Fonts', 'modern-admin-styler' ); ?>">
											<option value="system" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'system' ); ?>><?php esc_html_e( 'System Default', 'modern-admin-styler' ); ?></option>
											<option value="Arial, sans-serif" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'Arial, sans-serif' ); ?>>Arial</option>
											<option value="Helvetica, sans-serif" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'Helvetica, sans-serif' ); ?>>Helvetica</option>
											<option value="Georgia, serif" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'Georgia, serif' ); ?>>Georgia</option>
											<option value="'Courier New', monospace" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', "'Courier New', monospace" ); ?>>Courier New</option>
											<option value="'Times New Roman', serif" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', "'Times New Roman', serif" ); ?>>Times New Roman</option>
										</optgroup>
										<optgroup label="<?php esc_attr_e( 'Google Fonts', 'modern-admin-styler' ); ?>">
											<option value="google:Roboto" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Roboto' ); ?>>Roboto</option>
											<option value="google:Open Sans" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Open Sans' ); ?>>Open Sans</option>
											<option value="google:Lato" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Lato' ); ?>>Lato</option>
											<option value="google:Montserrat" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Montserrat' ); ?>>Montserrat</option>
											<option value="google:Poppins" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Poppins' ); ?>>Poppins</option>
											<option value="google:Inter" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Inter' ); ?>>Inter</option>
											<option value="google:Raleway" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Raleway' ); ?>>Raleway</option>
											<option value="google:Source Sans Pro" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Source Sans Pro' ); ?>>Source Sans Pro</option>
											<option value="google:Nunito" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Nunito' ); ?>>Nunito</option>
											<option value="google:Ubuntu" <?php selected( $settings['typography']['admin_bar']['font_family'] ?? 'system', 'google:Ubuntu' ); ?>>Ubuntu</option>
										</optgroup>
									</select>
									<input type="hidden" id="admin-bar-google-font-url" name="typography[admin_bar][google_font_url]" value="<?php echo esc_attr( $settings['typography']['admin_bar']['google_font_url'] ?? '' ); ?>" />
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Admin Bar Visual Effects -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Admin Bar Visual Effects', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Apply modern visual effects to the admin bar.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-glassmorphism">
										<?php esc_html_e( 'Glassmorphism', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="admin-bar-glassmorphism"
											name="visual_effects[admin_bar][glassmorphism]" 
											value="1"
											<?php checked( $settings['visual_effects']['admin_bar']['glassmorphism'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['admin_bar']['glassmorphism'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="admin-bar-glassmorphism-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="admin-bar-glassmorphism-desc"><?php esc_html_e( 'Apply frosted glass effect with backdrop blur.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-glassmorphism">
								<div class="mase-setting-label">
									<label for="admin-bar-blur-intensity">
										<?php esc_html_e( 'Blur Intensity (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-blur-intensity"
										name="visual_effects[admin_bar][blur_intensity]" 
										value="<?php echo esc_attr( $settings['visual_effects']['admin_bar']['blur_intensity'] ?? 20 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['visual_effects']['admin_bar']['blur_intensity'] ?? 20 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-floating">
										<?php esc_html_e( 'Floating Effect', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="admin-bar-floating"
											name="visual_effects[admin_bar][floating]" 
											value="1"
											<?php checked( $settings['visual_effects']['admin_bar']['floating'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['admin_bar']['floating'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="admin-bar-floating-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="admin-bar-floating-desc"><?php esc_html_e( 'Add margin to create floating appearance.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-floating">
								<div class="mase-setting-label">
									<label for="admin-bar-floating-margin">
										<?php esc_html_e( 'Floating Margin (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-floating-margin"
										name="visual_effects[admin_bar][floating_margin]" 
										value="<?php echo esc_attr( $settings['visual_effects']['admin_bar']['floating_margin'] ?? 8 ); ?>"
										min="0"
										max="20"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['visual_effects']['admin_bar']['floating_margin'] ?? 8 ); ?>px</span>
								</div>
							</div>
							
							<!-- Individual Corner Radius Controls (Requirements 9.1, 9.2, 9.3) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-border-radius-mode">
										<?php esc_html_e( 'Border Radius Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-border-radius-mode" name="admin_bar[border_radius_mode]">
										<option value="uniform" <?php selected( $settings['admin_bar']['border_radius_mode'] ?? 'uniform', 'uniform' ); ?>><?php esc_html_e( 'Uniform', 'modern-admin-styler' ); ?></option>
										<option value="individual" <?php selected( $settings['admin_bar']['border_radius_mode'] ?? 'uniform', 'individual' ); ?>><?php esc_html_e( 'Individual Corners', 'modern-admin-styler' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Choose between uniform radius for all corners or individual control.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-border-radius-mode" data-value="uniform">
								<div class="mase-setting-label">
									<label for="admin-bar-border-radius">
										<?php esc_html_e( 'All Corners (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-border-radius"
										name="admin_bar[border_radius]" 
										value="<?php echo esc_attr( $settings['admin_bar']['border_radius'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['border_radius'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-border-radius-mode" data-value="individual">
								<div class="mase-setting-label">
									<label for="admin-bar-border-radius-tl">
										<?php esc_html_e( 'Top Left (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-border-radius-tl"
										name="admin_bar[border_radius_tl]" 
										value="<?php echo esc_attr( $settings['admin_bar']['border_radius_tl'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['border_radius_tl'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-border-radius-mode" data-value="individual">
								<div class="mase-setting-label">
									<label for="admin-bar-border-radius-tr">
										<?php esc_html_e( 'Top Right (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-border-radius-tr"
										name="admin_bar[border_radius_tr]" 
										value="<?php echo esc_attr( $settings['admin_bar']['border_radius_tr'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['border_radius_tr'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-border-radius-mode" data-value="individual">
								<div class="mase-setting-label">
									<label for="admin-bar-border-radius-bl">
										<?php esc_html_e( 'Bottom Left (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-border-radius-bl"
										name="admin_bar[border_radius_bl]" 
										value="<?php echo esc_attr( $settings['admin_bar']['border_radius_bl'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['border_radius_bl'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-border-radius-mode" data-value="individual">
								<div class="mase-setting-label">
									<label for="admin-bar-border-radius-br">
										<?php esc_html_e( 'Bottom Right (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-border-radius-br"
										name="admin_bar[border_radius_br]" 
										value="<?php echo esc_attr( $settings['admin_bar']['border_radius_br'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['border_radius_br'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<!-- Advanced Shadow Controls (Requirements 10.1, 10.2, 10.3, 10.4) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-shadow-mode">
										<?php esc_html_e( 'Shadow Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-shadow-mode" name="admin_bar[shadow_mode]">
										<option value="preset" <?php selected( $settings['admin_bar']['shadow_mode'] ?? 'preset', 'preset' ); ?>><?php esc_html_e( 'Preset', 'modern-admin-styler' ); ?></option>
										<option value="custom" <?php selected( $settings['admin_bar']['shadow_mode'] ?? 'preset', 'custom' ); ?>><?php esc_html_e( 'Custom', 'modern-admin-styler' ); ?></option>
									</select>
								</div>
							</div>

							<!-- Preset Shadow Controls (Requirement 10.1) -->
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-bar-shadow-mode" data-value="preset">
								<div class="mase-setting-label">
									<label for="admin-bar-shadow-preset">
										<?php esc_html_e( 'Shadow Preset', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-shadow-preset" name="admin_bar[shadow_preset]">
										<option value="none" <?php selected( $settings['admin_bar']['shadow_preset'] ?? 'none', 'none' ); ?>><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
										<option value="subtle" <?php selected( $settings['admin_bar']['shadow_preset'] ?? 'none', 'subtle' ); ?>><?php esc_html_e( 'Subtle', 'modern-admin-styler' ); ?></option>
										<option value="medium" <?php selected( $settings['admin_bar']['shadow_preset'] ?? 'none', 'medium' ); ?>><?php esc_html_e( 'Medium', 'modern-admin-styler' ); ?></option>
										<option value="strong" <?php selected( $settings['admin_bar']['shadow_preset'] ?? 'none', 'strong' ); ?>><?php esc_html_e( 'Strong', 'modern-admin-styler' ); ?></option>
										<option value="dramatic" <?php selected( $settings['admin_bar']['shadow_preset'] ?? 'none', 'dramatic' ); ?>><?php esc_html_e( 'Dramatic', 'modern-admin-styler' ); ?></option>
									</select>
								</div>
							</div>

							<!-- Custom Shadow Controls (Requirements 10.2, 10.3, 10.4) -->
							<div class="mase-conditional" data-depends-on="admin-bar-shadow-mode" data-value="custom">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-shadow-h-offset">
											<?php esc_html_e( 'Horizontal Offset (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-shadow-h-offset"
											name="admin_bar[shadow_h_offset]"
											value="<?php echo esc_attr( $settings['admin_bar']['shadow_h_offset'] ?? 0 ); ?>"
											min="-50"
											max="50"
											step="1"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['shadow_h_offset'] ?? 0 ); ?>px</span>
									</div>
								</div>

								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-shadow-v-offset">
											<?php esc_html_e( 'Vertical Offset (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-shadow-v-offset"
											name="admin_bar[shadow_v_offset]"
											value="<?php echo esc_attr( $settings['admin_bar']['shadow_v_offset'] ?? 4 ); ?>"
											min="-50"
											max="50"
											step="1"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['shadow_v_offset'] ?? 4 ); ?>px</span>
									</div>
								</div>

								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-shadow-blur">
											<?php esc_html_e( 'Blur Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-shadow-blur"
											name="admin_bar[shadow_blur]"
											value="<?php echo esc_attr( $settings['admin_bar']['shadow_blur'] ?? 8 ); ?>"
											min="0"
											max="100"
											step="1"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['shadow_blur'] ?? 8 ); ?>px</span>
									</div>
								</div>

								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-shadow-spread">
											<?php esc_html_e( 'Spread Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-shadow-spread"
											name="admin_bar[shadow_spread]"
											value="<?php echo esc_attr( $settings['admin_bar']['shadow_spread'] ?? 0 ); ?>"
											min="-50"
											max="50"
											step="1"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['shadow_spread'] ?? 0 ); ?>px</span>
									</div>
								</div>

								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-shadow-color">
											<?php esc_html_e( 'Shadow Color', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="admin-bar-shadow-color"
											class="mase-color-picker"
											name="admin_bar[shadow_color]"
											value="<?php echo esc_attr( $settings['admin_bar']['shadow_color'] ?? '#000000' ); ?>"
										/>
									</div>
								</div>

								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-shadow-opacity">
											<?php esc_html_e( 'Shadow Opacity', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-shadow-opacity"
											name="admin_bar[shadow_opacity]"
											value="<?php echo esc_attr( $settings['admin_bar']['shadow_opacity'] ?? 0.15 ); ?>"
											min="0"
											max="1"
											step="0.05"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['shadow_opacity'] ?? 0.15 ); ?></span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Admin Bar Width Controls (Requirements 11.1, 11.2, 11.3) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Width Controls', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Control the width of the admin bar in pixels or percentage.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-width-unit">
										<?php esc_html_e( 'Width Unit', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-width-unit" name="admin_bar[width_unit]">
										<option value="percent" <?php selected( $settings['admin_bar']['width_unit'] ?? 'percent', 'percent' ); ?>>
											<?php esc_html_e( 'Percentage (%)', 'modern-admin-styler' ); ?>
										</option>
										<option value="pixels" <?php selected( $settings['admin_bar']['width_unit'] ?? 'percent', 'pixels' ); ?>>
											<?php esc_html_e( 'Pixels (px)', 'modern-admin-styler' ); ?>
										</option>
									</select>
									<p class="description"><?php esc_html_e( 'Choose between percentage or pixel-based width.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Percentage Width Control (shown when width_unit = percent) -->
							<div class="mase-conditional-group" data-depends-on="admin-bar-width-unit" data-value="percent" style="display: <?php echo ( ! isset( $settings['admin_bar']['width_unit'] ) || $settings['admin_bar']['width_unit'] === 'percent' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-width-value-percent">
											<?php esc_html_e( 'Width (%)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-width-value-percent"
											name="admin_bar[width_value]" 
											min="50"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['admin_bar']['width_value'] ?? 100 ); ?>"
											data-unit="percent"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['width_value'] ?? 100 ); ?>%</span>
										<p class="description"><?php esc_html_e( 'Range: 50-100%. Admin bar will be centered if less than 100%.', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
							</div>
							
							<!-- Pixel Width Control (shown when width_unit = pixels) -->
							<div class="mase-conditional-group" data-depends-on="admin-bar-width-unit" data-value="pixels" style="display: <?php echo ( isset( $settings['admin_bar']['width_unit'] ) && $settings['admin_bar']['width_unit'] === 'pixels' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-width-value-pixels">
											<?php esc_html_e( 'Width (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-width-value-pixels"
											name="admin_bar[width_value]" 
											min="800"
											max="3000"
											step="10"
											value="<?php echo esc_attr( $settings['admin_bar']['width_value'] ?? 1920 ); ?>"
											data-unit="pixels"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['width_value'] ?? 1920 ); ?>px</span>
										<p class="description"><?php esc_html_e( 'Range: 800-3000px. Admin bar will be centered.', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Individual Floating Margin Controls (Requirements 12.1, 12.2, 12.3) -->
				<div class="mase-section mase-conditional" data-depends-on="admin-bar-floating">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Floating Margins', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Control the margins around the floating admin bar. Only visible when floating mode is enabled.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-floating-margin-mode">
										<?php esc_html_e( 'Margin Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-floating-margin-mode" name="admin_bar[floating_margin_mode]">
										<option value="uniform" <?php selected( $settings['admin_bar']['floating_margin_mode'] ?? 'uniform', 'uniform' ); ?>>
											<?php esc_html_e( 'Uniform', 'modern-admin-styler' ); ?>
										</option>
										<option value="individual" <?php selected( $settings['admin_bar']['floating_margin_mode'] ?? 'uniform', 'individual' ); ?>>
											<?php esc_html_e( 'Individual Sides', 'modern-admin-styler' ); ?>
										</option>
									</select>
									<p class="description"><?php esc_html_e( 'Choose between uniform margin for all sides or individual control.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Uniform Margin Control (shown when floating_margin_mode = uniform) -->
							<div class="mase-conditional-group" data-depends-on="admin-bar-floating-margin-mode" data-value="uniform" style="display: <?php echo ( ! isset( $settings['admin_bar']['floating_margin_mode'] ) || $settings['admin_bar']['floating_margin_mode'] === 'uniform' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-floating-margin-uniform">
											<?php esc_html_e( 'All Sides (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-floating-margin-uniform"
											name="admin_bar[floating_margin]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['admin_bar']['floating_margin'] ?? 8 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['floating_margin'] ?? 8 ); ?>px</span>
										<p class="description"><?php esc_html_e( 'Apply the same margin to all sides.', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
							</div>
							
							<!-- Individual Margin Controls (shown when floating_margin_mode = individual) -->
							<div class="mase-conditional-group" data-depends-on="admin-bar-floating-margin-mode" data-value="individual" style="display: <?php echo ( isset( $settings['admin_bar']['floating_margin_mode'] ) && $settings['admin_bar']['floating_margin_mode'] === 'individual' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-floating-margin-top">
											<?php esc_html_e( 'Top (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-floating-margin-top"
											name="admin_bar[floating_margin_top]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['admin_bar']['floating_margin_top'] ?? 8 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['floating_margin_top'] ?? 8 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-floating-margin-right">
											<?php esc_html_e( 'Right (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-floating-margin-right"
											name="admin_bar[floating_margin_right]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['admin_bar']['floating_margin_right'] ?? 8 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['floating_margin_right'] ?? 8 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-floating-margin-bottom">
											<?php esc_html_e( 'Bottom (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-floating-margin-bottom"
											name="admin_bar[floating_margin_bottom]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['admin_bar']['floating_margin_bottom'] ?? 8 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['floating_margin_bottom'] ?? 8 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-bar-floating-margin-left">
											<?php esc_html_e( 'Left (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-bar-floating-margin-left"
											name="admin_bar[floating_margin_left]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['admin_bar']['floating_margin_left'] ?? 8 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar']['floating_margin_left'] ?? 8 ); ?>px</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Admin Bar Submenu Styling (Requirements 6.1, 6.2, 6.3) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Submenu Styling', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the appearance of admin bar dropdown submenus.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-submenu-bg-color">
										<?php esc_html_e( 'Background Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-bar-submenu-bg-color"
										name="admin_bar_submenu[bg_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_bar_submenu']['bg_color'] ?? '#32373c' ); ?>"
										data-default-color="#32373c"
									/>
									<p class="description"><?php esc_html_e( 'Background color for submenu dropdowns.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-submenu-border-radius">
										<?php esc_html_e( 'Border Radius (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-submenu-border-radius"
										name="admin_bar_submenu[border_radius]" 
										value="<?php echo esc_attr( $settings['admin_bar_submenu']['border_radius'] ?? 0 ); ?>"
										min="0"
										max="20"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar_submenu']['border_radius'] ?? 0 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Rounded corners for submenu dropdowns.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-submenu-spacing">
										<?php esc_html_e( 'Spacing from Admin Bar (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-bar-submenu-spacing"
										name="admin_bar_submenu[spacing]" 
										value="<?php echo esc_attr( $settings['admin_bar_submenu']['spacing'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_bar_submenu']['spacing'] ?? 0 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Vertical distance between admin bar and submenu.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- NEW: Submenu Font Family Selector (Requirement 8.1, 8.4) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-bar-submenu-font-family">
										<?php esc_html_e( 'Font Family', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-bar-submenu-font-family" name="admin_bar_submenu[font_family]">
										<optgroup label="<?php esc_attr_e( 'System Fonts', 'modern-admin-styler' ); ?>">
											<option value="system" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'system' ); ?>><?php esc_html_e( 'System Default', 'modern-admin-styler' ); ?></option>
											<option value="Arial, sans-serif" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'Arial, sans-serif' ); ?>>Arial</option>
											<option value="Helvetica, sans-serif" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'Helvetica, sans-serif' ); ?>>Helvetica</option>
											<option value="Georgia, serif" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'Georgia, serif' ); ?>>Georgia</option>
											<option value="'Courier New', monospace" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', "'Courier New', monospace" ); ?>>Courier New</option>
											<option value="'Times New Roman', serif" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', "'Times New Roman', serif" ); ?>>Times New Roman</option>
										</optgroup>
										<optgroup label="<?php esc_attr_e( 'Google Fonts', 'modern-admin-styler' ); ?>">
											<option value="google:Roboto" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Roboto' ); ?>>Roboto</option>
											<option value="google:Open Sans" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Open Sans' ); ?>>Open Sans</option>
											<option value="google:Lato" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Lato' ); ?>>Lato</option>
											<option value="google:Montserrat" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Montserrat' ); ?>>Montserrat</option>
											<option value="google:Poppins" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Poppins' ); ?>>Poppins</option>
											<option value="google:Inter" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Inter' ); ?>>Inter</option>
											<option value="google:Raleway" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Raleway' ); ?>>Raleway</option>
											<option value="google:Source Sans Pro" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Source Sans Pro' ); ?>>Source Sans Pro</option>
											<option value="google:Nunito" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Nunito' ); ?>>Nunito</option>
											<option value="google:Ubuntu" <?php selected( $settings['admin_bar_submenu']['font_family'] ?? 'system', 'google:Ubuntu' ); ?>>Ubuntu</option>
										</optgroup>
									</select>
									<p class="description"><?php esc_html_e( 'Font family for submenu text.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div><!-- #tab-admin-bar -->


			<!-- ============================================ -->
			<!-- MENU TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-menu" data-tab-content="menu" role="tabpanel" aria-labelledby="tab-button-menu" tabindex="0">
				
				<!-- Menu Colors -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Menu Colors', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the colors of the admin menu.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-bg-color">
										<?php esc_html_e( 'Background Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-menu-bg-color"
										name="admin_menu[bg_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_menu']['bg_color'] ); ?>"
										data-default-color="#23282d"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-text-color">
										<?php esc_html_e( 'Text Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-menu-text-color"
										name="admin_menu[text_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_menu']['text_color'] ); ?>"
										data-default-color="#ffffff"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-hover-bg-color">
										<?php esc_html_e( 'Hover Background Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-menu-hover-bg-color"
										name="admin_menu[hover_bg_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_menu']['hover_bg_color'] ); ?>"
										data-default-color="#0073aa"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-hover-text-color">
										<?php esc_html_e( 'Hover Text Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-menu-hover-text-color"
										name="admin_menu[hover_text_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_menu']['hover_text_color'] ); ?>"
										data-default-color="#ffffff"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-width">
										<?php esc_html_e( 'Width', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<div class="mase-control-group">
										<select id="admin-menu-width-unit" name="admin_menu[width_unit]" class="mase-unit-toggle">
											<option value="pixels" <?php selected( $settings['admin_menu']['width_unit'] ?? 'pixels', 'pixels' ); ?>>
												<?php esc_html_e( 'Pixels', 'modern-admin-styler' ); ?>
											</option>
											<option value="percent" <?php selected( $settings['admin_menu']['width_unit'] ?? 'pixels', 'percent' ); ?>>
												<?php esc_html_e( 'Percentage', 'modern-admin-styler' ); ?>
											</option>
										</select>
										<input 
											type="number" 
											id="admin-menu-width"
											name="admin_menu[width_value]" 
											class="small-text"
											value="<?php echo esc_attr( $settings['admin_menu']['width_value'] ?? $settings['admin_menu']['width'] ?? 160 ); ?>"
											min="<?php echo ( isset( $settings['admin_menu']['width_unit'] ) && $settings['admin_menu']['width_unit'] === 'percent' ) ? '50' : '160'; ?>"
											max="<?php echo ( isset( $settings['admin_menu']['width_unit'] ) && $settings['admin_menu']['width_unit'] === 'percent' ) ? '100' : '400'; ?>"
											step="1"
											data-min-pixels="160"
											data-max-pixels="400"
											data-min-percent="50"
											data-max-percent="100"
										/>
										<span class="mase-unit-label">
											<?php echo ( isset( $settings['admin_menu']['width_unit'] ) && $settings['admin_menu']['width_unit'] === 'percent' ) ? '%' : 'px'; ?>
										</span>
									</div>
									<p class="description">
										<span class="mase-width-desc-pixels" style="display: <?php echo ( ! isset( $settings['admin_menu']['width_unit'] ) || $settings['admin_menu']['width_unit'] === 'pixels' ) ? 'inline' : 'none'; ?>;">
											<?php esc_html_e( 'Default: 160px. Range: 160-400px.', 'modern-admin-styler' ); ?>
										</span>
										<span class="mase-width-desc-percent" style="display: <?php echo ( isset( $settings['admin_menu']['width_unit'] ) && $settings['admin_menu']['width_unit'] === 'percent' ) ? 'inline' : 'none'; ?>;">
											<?php esc_html_e( 'Default: 100%. Range: 50-100%.', 'modern-admin-styler' ); ?>
										</span>
									</p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-height-mode">
										<?php esc_html_e( 'Height Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-height-mode" name="admin_menu[height_mode]">
										<option value="full" <?php selected( $settings['admin_menu']['height_mode'] ?? 'full', 'full' ); ?>><?php esc_html_e( 'Full Height (100%)', 'modern-admin-styler' ); ?></option>
										<option value="content" <?php selected( $settings['admin_menu']['height_mode'] ?? 'full', 'content' ); ?>><?php esc_html_e( 'Fit to Content', 'modern-admin-styler' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Full Height: Menu spans entire viewport. Fit to Content: Menu height adjusts to menu items.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Menu Gradient Background (Requirements 6.1, 6.2, 6.4) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Background Gradient', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Apply gradient backgrounds to the admin menu.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-bg-type">
										<?php esc_html_e( 'Background Type', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-bg-type" name="admin_menu[bg_type]">
										<option value="solid" <?php selected( $settings['admin_menu']['bg_type'] ?? 'solid', 'solid' ); ?>>
											<?php esc_html_e( 'Solid Color', 'modern-admin-styler' ); ?>
										</option>
										<option value="gradient" <?php selected( $settings['admin_menu']['bg_type'] ?? 'solid', 'gradient' ); ?>>
											<?php esc_html_e( 'Gradient', 'modern-admin-styler' ); ?>
										</option>
									</select>
								</div>
							</div>
							
							<!-- Gradient Controls (shown when bg_type = gradient) -->
							<div class="mase-conditional-group" data-depends-on="admin-menu-bg-type" data-value="gradient" style="display: <?php echo ( isset( $settings['admin_menu']['bg_type'] ) && $settings['admin_menu']['bg_type'] === 'gradient' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-gradient-type">
											<?php esc_html_e( 'Gradient Type', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<select id="admin-menu-gradient-type" name="admin_menu[gradient_type]">
											<option value="linear" <?php selected( $settings['admin_menu']['gradient_type'] ?? 'linear', 'linear' ); ?>>
												<?php esc_html_e( 'Linear', 'modern-admin-styler' ); ?>
											</option>
											<option value="radial" <?php selected( $settings['admin_menu']['gradient_type'] ?? 'linear', 'radial' ); ?>>
												<?php esc_html_e( 'Radial', 'modern-admin-styler' ); ?>
											</option>
											<option value="conic" <?php selected( $settings['admin_menu']['gradient_type'] ?? 'linear', 'conic' ); ?>>
												<?php esc_html_e( 'Conic', 'modern-admin-styler' ); ?>
											</option>
										</select>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-gradient-angle">
											<?php esc_html_e( 'Angle (degrees)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-gradient-angle"
											name="admin_menu[gradient_angle]" 
											min="0"
											max="360"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['gradient_angle'] ?? 90 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['gradient_angle'] ?? 90 ); ?>°</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-gradient-color-1">
											<?php esc_html_e( 'Color Stop 1', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="admin-menu-gradient-color-1"
											name="admin_menu[gradient_colors][0][color]" 
											class="mase-color-picker"
											value="<?php echo esc_attr( $settings['admin_menu']['gradient_colors'][0]['color'] ?? '#23282d' ); ?>"
											data-default-color="#23282d"
										/>
										<input 
											type="hidden" 
											name="admin_menu[gradient_colors][0][position]" 
											value="0"
										/>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-gradient-color-2">
											<?php esc_html_e( 'Color Stop 2', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="admin-menu-gradient-color-2"
											name="admin_menu[gradient_colors][1][color]" 
											class="mase-color-picker"
											value="<?php echo esc_attr( $settings['admin_menu']['gradient_colors'][1]['color'] ?? '#32373c' ); ?>"
											data-default-color="#32373c"
										/>
										<input 
											type="hidden" 
											name="admin_menu[gradient_colors][1][position]" 
											value="100"
										/>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Icon Color Synchronization (Requirement 2.3) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Icon Color', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Control how menu icons are colored. Auto mode syncs with text color, custom mode allows independent icon color.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-icon-color-mode">
										<?php esc_html_e( 'Icon Color Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-icon-color-mode" name="admin_menu[icon_color_mode]">
										<option value="auto" <?php selected( $settings['admin_menu']['icon_color_mode'] ?? 'auto', 'auto' ); ?>><?php esc_html_e( 'Auto (Sync with Text Color)', 'modern-admin-styler' ); ?></option>
										<option value="custom" <?php selected( $settings['admin_menu']['icon_color_mode'] ?? 'auto', 'custom' ); ?>><?php esc_html_e( 'Custom', 'modern-admin-styler' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Auto mode automatically matches icon color to text color. Custom mode allows independent icon color selection.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Custom Icon Color (shown when icon_color_mode = custom) -->
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-menu-icon-color-mode" data-value="custom" style="display: <?php echo ( isset( $settings['admin_menu']['icon_color_mode'] ) && $settings['admin_menu']['icon_color_mode'] === 'custom' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-icon-color">
										<?php esc_html_e( 'Custom Icon Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-menu-icon-color"
										name="admin_menu[icon_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_menu']['icon_color'] ?? '#ffffff' ); ?>"
										data-default-color="#ffffff"
									/>
									<p class="description"><?php esc_html_e( 'Choose a custom color for menu icons.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Menu Item Spacing (Requirement 1.2, 1.3) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Menu Item Spacing', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Control padding for menu items to create a compact, professional appearance.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-padding-vertical">
										<?php esc_html_e( 'Vertical Padding (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-padding-vertical"
										name="admin_menu[padding_vertical]" 
										value="<?php echo esc_attr( $settings['admin_menu']['padding_vertical'] ?? 10 ); ?>"
										min="5"
										max="30"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['padding_vertical'] ?? 10 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Default: 10px. Range: 5-30px.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-padding-horizontal">
										<?php esc_html_e( 'Horizontal Padding (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-padding-horizontal"
										name="admin_menu[padding_horizontal]" 
										value="<?php echo esc_attr( $settings['admin_menu']['padding_horizontal'] ?? 15 ); ?>"
										min="5"
										max="30"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['padding_horizontal'] ?? 15 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Default: 15px. Range: 5-30px.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Menu Typography -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Menu Typography', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the typography of the admin menu.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-font-size">
										<?php esc_html_e( 'Font Size (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="number" 
										id="admin-menu-font-size"
										name="typography[admin_menu][font_size]" 
										class="small-text"
										value="<?php echo esc_attr( $settings['typography']['admin_menu']['font_size'] ); ?>"
										min="10"
										max="24"
										step="1"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-font-weight">
										<?php esc_html_e( 'Font Weight', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-font-weight" name="typography[admin_menu][font_weight]">
										<option value="300" <?php selected( $settings['typography']['admin_menu']['font_weight'], 300 ); ?>>300 (Light)</option>
										<option value="400" <?php selected( $settings['typography']['admin_menu']['font_weight'], 400 ); ?>>400 (Normal)</option>
										<option value="500" <?php selected( $settings['typography']['admin_menu']['font_weight'], 500 ); ?>>500 (Medium)</option>
										<option value="600" <?php selected( $settings['typography']['admin_menu']['font_weight'], 600 ); ?>>600 (Semi-Bold)</option>
										<option value="700" <?php selected( $settings['typography']['admin_menu']['font_weight'], 700 ); ?>>700 (Bold)</option>
									</select>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-line-height">
										<?php esc_html_e( 'Line Height', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-line-height"
										name="typography[admin_menu][line_height]" 
										value="<?php echo esc_attr( $settings['typography']['admin_menu']['line_height'] ); ?>"
										min="1.0"
										max="2.0"
										step="0.1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['typography']['admin_menu']['line_height'] ); ?></span>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-letter-spacing">
										<?php esc_html_e( 'Letter Spacing (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-letter-spacing"
										name="typography[admin_menu][letter_spacing]" 
										value="<?php echo esc_attr( $settings['typography']['admin_menu']['letter_spacing'] ?? 0 ); ?>"
										min="-2"
										max="5"
										step="0.5"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['typography']['admin_menu']['letter_spacing'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-text-transform">
										<?php esc_html_e( 'Text Transform', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-text-transform" name="typography[admin_menu][text_transform]">
										<option value="none" <?php selected( $settings['typography']['admin_menu']['text_transform'] ?? 'none', 'none' ); ?>><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
										<option value="uppercase" <?php selected( $settings['typography']['admin_menu']['text_transform'] ?? 'none', 'uppercase' ); ?>><?php esc_html_e( 'Uppercase', 'modern-admin-styler' ); ?></option>
										<option value="lowercase" <?php selected( $settings['typography']['admin_menu']['text_transform'] ?? 'none', 'lowercase' ); ?>><?php esc_html_e( 'Lowercase', 'modern-admin-styler' ); ?></option>
										<option value="capitalize" <?php selected( $settings['typography']['admin_menu']['text_transform'] ?? 'none', 'capitalize' ); ?>><?php esc_html_e( 'Capitalize', 'modern-admin-styler' ); ?></option>
									</select>
								</div>
							</div>
							
							<!-- Font Family Control (Requirement 11.1, 11.4, 11.6) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-font-family">
										<?php esc_html_e( 'Font Family', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-font-family" name="typography[admin_menu][font_family]">
										<optgroup label="<?php esc_attr_e( 'System Fonts', 'modern-admin-styler' ); ?>">
											<option value="system" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'system' ); ?>><?php esc_html_e( 'System Default', 'modern-admin-styler' ); ?></option>
											<option value="Arial, sans-serif" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'Arial, sans-serif' ); ?>>Arial</option>
											<option value="Helvetica, sans-serif" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'Helvetica, sans-serif' ); ?>>Helvetica</option>
											<option value="Georgia, serif" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'Georgia, serif' ); ?>>Georgia</option>
											<option value="'Courier New', monospace" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', "'Courier New', monospace" ); ?>>Courier New</option>
											<option value="'Times New Roman', serif" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', "'Times New Roman', serif" ); ?>>Times New Roman</option>
										</optgroup>
										<optgroup label="<?php esc_attr_e( 'Google Fonts', 'modern-admin-styler' ); ?>">
											<option value="google:Roboto" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Roboto' ); ?>>Roboto</option>
											<option value="google:Open Sans" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Open Sans' ); ?>>Open Sans</option>
											<option value="google:Lato" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Lato' ); ?>>Lato</option>
											<option value="google:Montserrat" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Montserrat' ); ?>>Montserrat</option>
											<option value="google:Poppins" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Poppins' ); ?>>Poppins</option>
											<option value="google:Inter" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Inter' ); ?>>Inter</option>
											<option value="google:Raleway" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Raleway' ); ?>>Raleway</option>
											<option value="google:Source Sans Pro" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Source Sans Pro' ); ?>>Source Sans Pro</option>
											<option value="google:Nunito" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Nunito' ); ?>>Nunito</option>
											<option value="google:Ubuntu" <?php selected( $settings['typography']['admin_menu']['font_family'] ?? 'system', 'google:Ubuntu' ); ?>>Ubuntu</option>
										</optgroup>
									</select>
									<input type="hidden" id="admin-menu-google-font-url" name="typography[admin_menu][google_font_url]" value="<?php echo esc_attr( $settings['typography']['admin_menu']['google_font_url'] ?? '' ); ?>" />
									<p class="description"><?php esc_html_e( 'Choose a font family for menu items. Google Fonts are loaded dynamically.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Menu Visual Effects -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Menu Visual Effects', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Apply modern visual effects to the admin menu.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-glassmorphism">
										<?php esc_html_e( 'Glassmorphism', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="admin-menu-glassmorphism"
											name="visual_effects[admin_menu][glassmorphism]" 
											value="1"
											<?php checked( $settings['visual_effects']['admin_menu']['glassmorphism'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['admin_menu']['glassmorphism'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="admin-menu-glassmorphism-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="admin-menu-glassmorphism-desc"><?php esc_html_e( 'Apply frosted glass effect with backdrop blur.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-menu-glassmorphism">
								<div class="mase-setting-label">
									<label for="admin-menu-blur-intensity">
										<?php esc_html_e( 'Blur Intensity (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-blur-intensity"
										name="visual_effects[admin_menu][blur_intensity]" 
										value="<?php echo esc_attr( $settings['visual_effects']['admin_menu']['blur_intensity'] ?? 20 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['visual_effects']['admin_menu']['blur_intensity'] ?? 20 ); ?>px</span>
								</div>
							</div>
							
							<!-- Border Radius Mode (Requirements 12.1, 12.2, 12.3, 12.4) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-border-radius-mode">
										<?php esc_html_e( 'Border Radius Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-border-radius-mode" name="admin_menu[border_radius_mode]">
										<option value="uniform" <?php selected( $settings['admin_menu']['border_radius_mode'] ?? 'uniform', 'uniform' ); ?>>
											<?php esc_html_e( 'Uniform (All Corners)', 'modern-admin-styler' ); ?>
										</option>
										<option value="individual" <?php selected( $settings['admin_menu']['border_radius_mode'] ?? 'uniform', 'individual' ); ?>>
											<?php esc_html_e( 'Individual Corners', 'modern-admin-styler' ); ?>
										</option>
									</select>
									<p class="description"><?php esc_html_e( 'Choose between uniform or individual corner radius.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Uniform Border Radius (shown when mode = uniform) -->
							<div class="mase-setting-row mase-conditional-group" data-depends-on="admin-menu-border-radius-mode" data-value="uniform" style="display: <?php echo ( isset( $settings['admin_menu']['border_radius_mode'] ) && $settings['admin_menu']['border_radius_mode'] === 'individual' ) ? 'none' : 'flex'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-border-radius">
										<?php esc_html_e( 'Border Radius (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-border-radius"
										name="admin_menu[border_radius]" 
										value="<?php echo esc_attr( $settings['admin_menu']['border_radius'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['border_radius'] ?? 0 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Uniform corner rounding for all corners (0-50px).', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Individual Border Radius (shown when mode = individual) -->
							<div class="mase-conditional-group" data-depends-on="admin-menu-border-radius-mode" data-value="individual" style="display: <?php echo ( isset( $settings['admin_menu']['border_radius_mode'] ) && $settings['admin_menu']['border_radius_mode'] === 'individual' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-border-radius-tl">
											<?php esc_html_e( 'Top-Left Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-border-radius-tl"
											name="admin_menu[border_radius_tl]" 
											min="0"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['border_radius_tl'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['border_radius_tl'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-border-radius-tr">
											<?php esc_html_e( 'Top-Right Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-border-radius-tr"
											name="admin_menu[border_radius_tr]" 
											min="0"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['border_radius_tr'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['border_radius_tr'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-border-radius-br">
											<?php esc_html_e( 'Bottom-Right Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-border-radius-br"
											name="admin_menu[border_radius_br]" 
											min="0"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['border_radius_br'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['border_radius_br'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-border-radius-bl">
											<?php esc_html_e( 'Bottom-Left Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-border-radius-bl"
											name="admin_menu[border_radius_bl]" 
											min="0"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['border_radius_bl'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['border_radius_bl'] ?? 0 ); ?>px</span>
									</div>
								</div>
							</div>
							
							<!-- Shadow Mode (Requirements 13.1, 13.4) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-shadow-mode">
										<?php esc_html_e( 'Shadow Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-shadow-mode" name="admin_menu[shadow_mode]">
										<option value="preset" <?php selected( $settings['admin_menu']['shadow_mode'] ?? 'preset', 'preset' ); ?>>
											<?php esc_html_e( 'Preset Shadows', 'modern-admin-styler' ); ?>
										</option>
										<option value="custom" <?php selected( $settings['admin_menu']['shadow_mode'] ?? 'preset', 'custom' ); ?>>
											<?php esc_html_e( 'Custom Shadow', 'modern-admin-styler' ); ?>
										</option>
									</select>
									<p class="description"><?php esc_html_e( 'Choose between preset shadows or create a custom shadow.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Shadow Preset (shown when mode = preset) (Requirement 13.1) -->
							<div class="mase-setting-row mase-conditional-group" data-depends-on="admin-menu-shadow-mode" data-value="preset" style="display: <?php echo ( isset( $settings['admin_menu']['shadow_mode'] ) && $settings['admin_menu']['shadow_mode'] === 'custom' ) ? 'none' : 'flex'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-shadow-preset">
										<?php esc_html_e( 'Shadow Preset', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-shadow-preset" name="admin_menu[shadow_preset]">
										<option value="none" <?php selected( $settings['admin_menu']['shadow_preset'] ?? 'none', 'none' ); ?>><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
										<option value="subtle" <?php selected( $settings['admin_menu']['shadow_preset'] ?? 'none', 'subtle' ); ?>><?php esc_html_e( 'Subtle', 'modern-admin-styler' ); ?></option>
										<option value="medium" <?php selected( $settings['admin_menu']['shadow_preset'] ?? 'none', 'medium' ); ?>><?php esc_html_e( 'Medium', 'modern-admin-styler' ); ?></option>
										<option value="strong" <?php selected( $settings['admin_menu']['shadow_preset'] ?? 'none', 'strong' ); ?>><?php esc_html_e( 'Strong', 'modern-admin-styler' ); ?></option>
										<option value="dramatic" <?php selected( $settings['admin_menu']['shadow_preset'] ?? 'none', 'dramatic' ); ?>><?php esc_html_e( 'Dramatic', 'modern-admin-styler' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Select from predefined shadow styles.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Custom Shadow Controls (shown when mode = custom) (Requirements 13.2, 13.3) -->
							<div class="mase-conditional-group" data-depends-on="admin-menu-shadow-mode" data-value="custom" style="display: <?php echo ( isset( $settings['admin_menu']['shadow_mode'] ) && $settings['admin_menu']['shadow_mode'] === 'custom' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-shadow-h-offset">
											<?php esc_html_e( 'Horizontal Offset (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-shadow-h-offset"
											name="admin_menu[shadow_h_offset]" 
											min="-50"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['shadow_h_offset'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['shadow_h_offset'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-shadow-v-offset">
											<?php esc_html_e( 'Vertical Offset (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-shadow-v-offset"
											name="admin_menu[shadow_v_offset]" 
											min="-50"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['shadow_v_offset'] ?? 4 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['shadow_v_offset'] ?? 4 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-shadow-blur">
											<?php esc_html_e( 'Blur Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-shadow-blur"
											name="admin_menu[shadow_blur]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['shadow_blur'] ?? 8 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['shadow_blur'] ?? 8 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-shadow-spread">
											<?php esc_html_e( 'Spread Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-shadow-spread"
											name="admin_menu[shadow_spread]" 
											min="-50"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu']['shadow_spread'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['shadow_spread'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-shadow-color">
											<?php esc_html_e( 'Shadow Color', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="admin-menu-shadow-color"
											name="admin_menu[shadow_color]" 
											value="<?php echo esc_attr( $settings['admin_menu']['shadow_color'] ?? '#000000' ); ?>"
											class="mase-color-picker"
											data-alpha-enabled="false"
										/>
										<p class="description"><?php esc_html_e( 'Base color for the shadow.', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-shadow-opacity">
											<?php esc_html_e( 'Shadow Opacity', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-shadow-opacity"
											name="admin_menu[shadow_opacity]" 
											min="0"
											max="1"
											step="0.01"
											value="<?php echo esc_attr( $settings['admin_menu']['shadow_opacity'] ?? 0.15 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( round( ( $settings['admin_menu']['shadow_opacity'] ?? 0.15 ) * 100 ) ); ?>%</span>
									</div>
								</div>
							</div>
							
							<!-- Floating Mode (Requirements 15.1, 15.2, 15.3, 15.4) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-floating">
										<?php esc_html_e( 'Floating Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="admin-menu-floating"
											name="visual_effects[admin_menu][floating]" 
											value="1"
											<?php checked( $settings['visual_effects']['admin_menu']['floating'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['admin_menu']['floating'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="admin-menu-floating-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="admin-menu-floating-desc"><?php esc_html_e( 'Add margins around the menu to create a floating effect.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Floating Margin Controls (shown when floating is enabled) -->
							<div class="mase-conditional-group" data-depends-on="admin-menu-floating" style="display: <?php echo ( $settings['visual_effects']['admin_menu']['floating'] ?? false ) ? 'block' : 'none'; ?>;">
								<!-- Floating Margin Mode (Requirements 15.1, 15.2) -->
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-floating-margin-mode">
											<?php esc_html_e( 'Margin Mode', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<select id="admin-menu-floating-margin-mode" name="admin_menu[floating_margin_mode]">
											<option value="uniform" <?php selected( $settings['admin_menu']['floating_margin_mode'] ?? 'uniform', 'uniform' ); ?>>
												<?php esc_html_e( 'Uniform', 'modern-admin-styler' ); ?>
											</option>
											<option value="individual" <?php selected( $settings['admin_menu']['floating_margin_mode'] ?? 'uniform', 'individual' ); ?>>
												<?php esc_html_e( 'Individual Sides', 'modern-admin-styler' ); ?>
											</option>
										</select>
										<p class="description"><?php esc_html_e( 'Choose between uniform or individual side margins.', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
								
								<!-- Uniform Margin Control (shown when floating_margin_mode = uniform) (Requirement 15.1) -->
								<div class="mase-conditional-group" data-depends-on="admin-menu-floating-margin-mode" data-value="uniform" style="display: <?php echo ( ! isset( $settings['admin_menu']['floating_margin_mode'] ) || $settings['admin_menu']['floating_margin_mode'] === 'uniform' ) ? 'block' : 'none'; ?>;">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="admin-menu-floating-margin-uniform">
												<?php esc_html_e( 'Margin (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="admin-menu-floating-margin-uniform"
												name="admin_menu[floating_margin]" 
												min="0"
												max="100"
												step="1"
												value="<?php echo esc_attr( $settings['admin_menu']['floating_margin'] ?? 8 ); ?>"
											/>
											<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['floating_margin'] ?? 8 ); ?>px</span>
											<p class="description"><?php esc_html_e( 'Apply the same margin to all sides.', 'modern-admin-styler' ); ?></p>
										</div>
									</div>
								</div>
								
								<!-- Individual Margin Controls (shown when floating_margin_mode = individual) (Requirements 15.2, 15.3) -->
								<div class="mase-conditional-group" data-depends-on="admin-menu-floating-margin-mode" data-value="individual" style="display: <?php echo ( isset( $settings['admin_menu']['floating_margin_mode'] ) && $settings['admin_menu']['floating_margin_mode'] === 'individual' ) ? 'block' : 'none'; ?>;">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="admin-menu-floating-margin-top">
												<?php esc_html_e( 'Top Margin (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="admin-menu-floating-margin-top"
												name="admin_menu[floating_margin_top]" 
												min="0"
												max="100"
												step="1"
												value="<?php echo esc_attr( $settings['admin_menu']['floating_margin_top'] ?? 8 ); ?>"
											/>
											<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['floating_margin_top'] ?? 8 ); ?>px</span>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="admin-menu-floating-margin-right">
												<?php esc_html_e( 'Right Margin (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="admin-menu-floating-margin-right"
												name="admin_menu[floating_margin_right]" 
												min="0"
												max="100"
												step="1"
												value="<?php echo esc_attr( $settings['admin_menu']['floating_margin_right'] ?? 8 ); ?>"
											/>
											<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['floating_margin_right'] ?? 8 ); ?>px</span>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="admin-menu-floating-margin-bottom">
												<?php esc_html_e( 'Bottom Margin (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="admin-menu-floating-margin-bottom"
												name="admin_menu[floating_margin_bottom]" 
												min="0"
												max="100"
												step="1"
												value="<?php echo esc_attr( $settings['admin_menu']['floating_margin_bottom'] ?? 8 ); ?>"
											/>
											<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['floating_margin_bottom'] ?? 8 ); ?>px</span>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="admin-menu-floating-margin-left">
												<?php esc_html_e( 'Left Margin (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="admin-menu-floating-margin-left"
												name="admin_menu[floating_margin_left]" 
												min="0"
												max="100"
												step="1"
												value="<?php echo esc_attr( $settings['admin_menu']['floating_margin_left'] ?? 8 ); ?>"
											/>
											<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['floating_margin_left'] ?? 8 ); ?>px</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Menu Submenu Styling (Requirements 7.1, 7.2, 7.3, 7.4, 8.1, 8.2) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Submenu Styling', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the appearance of admin menu dropdown submenus.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-bg-color">
										<?php esc_html_e( 'Background Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-menu-submenu-bg-color"
										name="admin_menu_submenu[bg_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_menu_submenu']['bg_color'] ?? '#32373c' ); ?>"
										data-default-color="#32373c"
									/>
									<p class="description"><?php esc_html_e( 'Background color for submenu dropdowns.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Border Radius Controls (Requirement 8.1, 8.2) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-border-radius-mode">
										<?php esc_html_e( 'Border Radius Mode', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-submenu-border-radius-mode" name="admin_menu_submenu[border_radius_mode]">
										<option value="uniform" <?php selected( $settings['admin_menu_submenu']['border_radius_mode'] ?? 'uniform', 'uniform' ); ?>>
											<?php esc_html_e( 'Uniform (All Corners)', 'modern-admin-styler' ); ?>
										</option>
										<option value="individual" <?php selected( $settings['admin_menu_submenu']['border_radius_mode'] ?? 'uniform', 'individual' ); ?>>
											<?php esc_html_e( 'Individual Corners', 'modern-admin-styler' ); ?>
										</option>
									</select>
									<p class="description"><?php esc_html_e( 'Choose between uniform or individual corner radius.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Uniform Border Radius (shown when mode = uniform) -->
							<div class="mase-setting-row mase-conditional-group" data-depends-on="admin-menu-submenu-border-radius-mode" data-value="uniform" style="display: <?php echo ( isset( $settings['admin_menu_submenu']['border_radius_mode'] ) && $settings['admin_menu_submenu']['border_radius_mode'] === 'individual' ) ? 'none' : 'flex'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-border-radius">
										<?php esc_html_e( 'Border Radius (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-submenu-border-radius"
										name="admin_menu_submenu[border_radius]" 
										min="0"
										max="20"
										step="1"
										value="<?php echo esc_attr( $settings['admin_menu_submenu']['border_radius'] ?? 0 ); ?>"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['border_radius'] ?? 0 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Uniform corner rounding for all corners (0-20px).', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Individual Border Radius (shown when mode = individual) -->
							<div class="mase-conditional-group" data-depends-on="admin-menu-submenu-border-radius-mode" data-value="individual" style="display: <?php echo ( isset( $settings['admin_menu_submenu']['border_radius_mode'] ) && $settings['admin_menu_submenu']['border_radius_mode'] === 'individual' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-submenu-border-radius-tl">
											<?php esc_html_e( 'Top-Left Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-submenu-border-radius-tl"
											name="admin_menu_submenu[border_radius_tl]" 
											min="0"
											max="20"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu_submenu']['border_radius_tl'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['border_radius_tl'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-submenu-border-radius-tr">
											<?php esc_html_e( 'Top-Right Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-submenu-border-radius-tr"
											name="admin_menu_submenu[border_radius_tr]" 
											min="0"
											max="20"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu_submenu']['border_radius_tr'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['border_radius_tr'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-submenu-border-radius-br">
											<?php esc_html_e( 'Bottom-Right Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-submenu-border-radius-br"
											name="admin_menu_submenu[border_radius_br]" 
											min="0"
											max="20"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu_submenu']['border_radius_br'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['border_radius_br'] ?? 0 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="admin-menu-submenu-border-radius-bl">
											<?php esc_html_e( 'Bottom-Left Radius (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="admin-menu-submenu-border-radius-bl"
											name="admin_menu_submenu[border_radius_bl]" 
											min="0"
											max="20"
											step="1"
											value="<?php echo esc_attr( $settings['admin_menu_submenu']['border_radius_bl'] ?? 0 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['border_radius_bl'] ?? 0 ); ?>px</span>
									</div>
								</div>
							</div>
							
							<!-- Submenu Spacing Control (Requirement 9.1) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-spacing">
										<?php esc_html_e( 'Spacing from Menu (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-submenu-spacing"
										name="admin_menu_submenu[spacing]" 
										value="<?php echo esc_attr( $settings['admin_menu_submenu']['spacing'] ?? 0 ); ?>"
										min="0"
										max="50"
										step="1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['spacing'] ?? 0 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Vertical distance between menu and submenu.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Submenu Typography (Requirements 10.1, 10.2, 10.3, 10.4, 10.5) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Submenu Typography', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the typography of submenu items independently from the main menu.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<!-- Font Size Control (Requirement 10.1) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-font-size">
										<?php esc_html_e( 'Font Size (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="number" 
										id="admin-menu-submenu-font-size"
										name="admin_menu_submenu[font_size]" 
										class="small-text"
										value="<?php echo esc_attr( $settings['admin_menu_submenu']['font_size'] ?? 13 ); ?>"
										min="10"
										max="24"
										step="1"
									/>
									<p class="description"><?php esc_html_e( 'Font size for submenu items (10-24px).', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Text Color Control (Requirement 10.2) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-text-color">
										<?php esc_html_e( 'Text Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="admin-menu-submenu-text-color"
										name="admin_menu_submenu[text_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['admin_menu_submenu']['text_color'] ?? '#ffffff' ); ?>"
										data-default-color="#ffffff"
									/>
									<p class="description"><?php esc_html_e( 'Text color for submenu items.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Line Height Control (Requirement 10.3) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-line-height">
										<?php esc_html_e( 'Line Height', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-submenu-line-height"
										name="admin_menu_submenu[line_height]" 
										value="<?php echo esc_attr( $settings['admin_menu_submenu']['line_height'] ?? 1.5 ); ?>"
										min="1.0"
										max="3.0"
										step="0.1"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['line_height'] ?? 1.5 ); ?></span>
									<p class="description"><?php esc_html_e( 'Line height for submenu items (1.0-3.0).', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Letter Spacing Control (Requirement 10.4) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-letter-spacing">
										<?php esc_html_e( 'Letter Spacing (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-submenu-letter-spacing"
										name="admin_menu_submenu[letter_spacing]" 
										value="<?php echo esc_attr( $settings['admin_menu_submenu']['letter_spacing'] ?? 0 ); ?>"
										min="-2"
										max="5"
										step="0.5"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu_submenu']['letter_spacing'] ?? 0 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Letter spacing for submenu items (-2 to 5px).', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Text Transform Control (Requirement 10.5) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-text-transform">
										<?php esc_html_e( 'Text Transform', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-submenu-text-transform" name="admin_menu_submenu[text_transform]">
										<option value="none" <?php selected( $settings['admin_menu_submenu']['text_transform'] ?? 'none', 'none' ); ?>><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
										<option value="uppercase" <?php selected( $settings['admin_menu_submenu']['text_transform'] ?? 'none', 'uppercase' ); ?>><?php esc_html_e( 'Uppercase', 'modern-admin-styler' ); ?></option>
										<option value="lowercase" <?php selected( $settings['admin_menu_submenu']['text_transform'] ?? 'none', 'lowercase' ); ?>><?php esc_html_e( 'Lowercase', 'modern-admin-styler' ); ?></option>
										<option value="capitalize" <?php selected( $settings['admin_menu_submenu']['text_transform'] ?? 'none', 'capitalize' ); ?>><?php esc_html_e( 'Capitalize', 'modern-admin-styler' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Text transformation for submenu items.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Font Family Control (Requirement 11.1) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-submenu-font-family">
										<?php esc_html_e( 'Font Family', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-submenu-font-family" name="admin_menu_submenu[font_family]">
										<optgroup label="<?php esc_attr_e( 'System Fonts', 'modern-admin-styler' ); ?>">
											<option value="system" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'system' ); ?>><?php esc_html_e( 'System Default', 'modern-admin-styler' ); ?></option>
											<option value="Arial, sans-serif" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'Arial, sans-serif' ); ?>>Arial</option>
											<option value="Helvetica, sans-serif" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'Helvetica, sans-serif' ); ?>>Helvetica</option>
											<option value="Georgia, serif" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'Georgia, serif' ); ?>>Georgia</option>
											<option value="'Courier New', monospace" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', "'Courier New', monospace" ); ?>>Courier New</option>
											<option value="'Times New Roman', serif" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', "'Times New Roman', serif" ); ?>>Times New Roman</option>
										</optgroup>
										<optgroup label="<?php esc_attr_e( 'Google Fonts', 'modern-admin-styler' ); ?>">
											<option value="google:Roboto" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Roboto' ); ?>>Roboto</option>
											<option value="google:Open Sans" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Open Sans' ); ?>>Open Sans</option>
											<option value="google:Lato" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Lato' ); ?>>Lato</option>
											<option value="google:Montserrat" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Montserrat' ); ?>>Montserrat</option>
											<option value="google:Poppins" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Poppins' ); ?>>Poppins</option>
											<option value="google:Inter" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Inter' ); ?>>Inter</option>
											<option value="google:Raleway" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Raleway' ); ?>>Raleway</option>
											<option value="google:Source Sans Pro" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Source Sans Pro' ); ?>>Source Sans Pro</option>
											<option value="google:Nunito" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Nunito' ); ?>>Nunito</option>
											<option value="google:Ubuntu" <?php selected( $settings['admin_menu_submenu']['font_family'] ?? 'system', 'google:Ubuntu' ); ?>>Ubuntu</option>
										</optgroup>
									</select>
									<p class="description"><?php esc_html_e( 'Font family for submenu items.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<!-- Logo Placement Section (Requirement 16) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Logo Placement', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Add and position a custom logo in the admin menu.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							
							<!-- Logo Enable Toggle (Requirement 16.1) -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="admin-menu-logo-enabled">
										<?php esc_html_e( 'Enable Logo', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="admin-menu-logo-enabled"
											name="admin_menu[logo_enabled]" 
											value="1"
											<?php checked( $settings['admin_menu']['logo_enabled'] ?? false, true ); ?>
										/>
										<span class="mase-toggle-slider"></span>
									</label>
									<p class="description"><?php esc_html_e( 'Enable custom logo in the admin menu.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Logo Upload Control (Requirement 16.1) -->
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-menu-logo-enabled" style="display: <?php echo ( $settings['admin_menu']['logo_enabled'] ?? false ) ? 'flex' : 'none'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-logo-upload">
										<?php esc_html_e( 'Logo Image', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<div class="mase-logo-upload-wrapper">
										<input 
											type="hidden" 
											id="admin-menu-logo-url"
											name="admin_menu[logo_url]" 
											value="<?php echo esc_attr( $settings['admin_menu']['logo_url'] ?? '' ); ?>"
										/>
										<button 
											type="button" 
											id="admin-menu-logo-upload-btn"
											class="button button-secondary mase-logo-upload-btn"
										>
											<span class="dashicons dashicons-upload"></span>
											<?php esc_html_e( 'Upload Logo', 'modern-admin-styler' ); ?>
										</button>
										<button 
											type="button" 
											id="admin-menu-logo-remove-btn"
											class="button button-secondary mase-logo-remove-btn"
											style="<?php echo empty( $settings['admin_menu']['logo_url'] ) ? 'display: none;' : ''; ?>"
										>
											<span class="dashicons dashicons-no"></span>
											<?php esc_html_e( 'Remove Logo', 'modern-admin-styler' ); ?>
										</button>
										<div id="admin-menu-logo-preview" class="mase-logo-preview" style="<?php echo empty( $settings['admin_menu']['logo_url'] ) ? 'display: none;' : ''; ?>">
											<?php if ( ! empty( $settings['admin_menu']['logo_url'] ) ) : ?>
												<img src="<?php echo esc_url( $settings['admin_menu']['logo_url'] ); ?>" alt="<?php esc_attr_e( 'Menu Logo', 'modern-admin-styler' ); ?>" />
											<?php endif; ?>
										</div>
									</div>
									<p class="description"><?php esc_html_e( 'Upload a logo image (PNG, JPG, or SVG, max 2MB).', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Logo Position Control (Requirement 16.2) -->
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-menu-logo-enabled" style="display: <?php echo ( $settings['admin_menu']['logo_enabled'] ?? false ) ? 'flex' : 'none'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-logo-position">
										<?php esc_html_e( 'Logo Position', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-logo-position" name="admin_menu[logo_position]">
										<option value="top" <?php selected( $settings['admin_menu']['logo_position'] ?? 'top', 'top' ); ?>><?php esc_html_e( 'Top', 'modern-admin-styler' ); ?></option>
										<option value="bottom" <?php selected( $settings['admin_menu']['logo_position'] ?? 'top', 'bottom' ); ?>><?php esc_html_e( 'Bottom', 'modern-admin-styler' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Position logo at the top or bottom of the menu.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Logo Width Control (Requirement 16.3) -->
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-menu-logo-enabled" style="display: <?php echo ( $settings['admin_menu']['logo_enabled'] ?? false ) ? 'flex' : 'none'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-logo-width">
										<?php esc_html_e( 'Logo Width (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="admin-menu-logo-width"
										name="admin_menu[logo_width]" 
										value="<?php echo esc_attr( $settings['admin_menu']['logo_width'] ?? 100 ); ?>"
										min="20"
										max="200"
										step="5"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['admin_menu']['logo_width'] ?? 100 ); ?>px</span>
									<p class="description"><?php esc_html_e( 'Logo width in pixels (20-200px). Height adjusts automatically.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<!-- Logo Alignment Control (Requirement 16.4) -->
							<div class="mase-setting-row mase-conditional" data-depends-on="admin-menu-logo-enabled" style="display: <?php echo ( $settings['admin_menu']['logo_enabled'] ?? false ) ? 'flex' : 'none'; ?>;">
								<div class="mase-setting-label">
									<label for="admin-menu-logo-alignment">
										<?php esc_html_e( 'Logo Alignment', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="admin-menu-logo-alignment" name="admin_menu[logo_alignment]">
										<option value="left" <?php selected( $settings['admin_menu']['logo_alignment'] ?? 'center', 'left' ); ?>><?php esc_html_e( 'Left', 'modern-admin-styler' ); ?></option>
										<option value="center" <?php selected( $settings['admin_menu']['logo_alignment'] ?? 'center', 'center' ); ?>><?php esc_html_e( 'Center', 'modern-admin-styler' ); ?></option>
										<option value="right" <?php selected( $settings['admin_menu']['logo_alignment'] ?? 'center', 'right' ); ?>><?php esc_html_e( 'Right', 'modern-admin-styler' ); ?></option>
									</select>
									<p class="description"><?php esc_html_e( 'Horizontal alignment of the logo.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				
			</div><!-- #tab-menu -->


			<!-- ============================================ -->
			<!-- CONTENT TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-content" data-tab-content="content" role="tabpanel" aria-labelledby="tab-button-content" tabindex="0">
				<?php
				// Load Content Tab template (Task 7 - Requirements 4.1, 4.2, 4.3, 4.4, 4.5)
				require_once MASE_PLUGIN_DIR . 'includes/templates/content-tab.php';
				?>
			</div><!-- #tab-content -->

		<!-- ============================================ -->
		<!-- TYPOGRAPHY TAB -->
		<!-- ============================================ -->
		<div class="mase-tab-content" id="tab-typography" data-tab-content="typography" role="tabpanel" aria-labelledby="tab-button-typography" tabindex="0">
			
			<!-- Area Selector -->
			<div class="mase-section">
				<div class="mase-section-header">
					<h2><?php esc_html_e( 'Content Typography System', 'modern-admin-styler' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Customize typography for different admin content areas with advanced font controls.', 'modern-admin-styler' ); ?></p>
				</div>
				
				<div class="mase-typography-area-selector" role="tablist" aria-label="<?php esc_attr_e( 'Typography areas', 'modern-admin-styler' ); ?>">
					<button type="button" class="mase-area-button active" data-area="body_text" role="tab" aria-selected="true" aria-controls="typography-body_text">
						<span class="dashicons dashicons-editor-paragraph" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Body Text', 'modern-admin-styler' ); ?></span>
					</button>
					<button type="button" class="mase-area-button" data-area="headings" role="tab" aria-selected="false" aria-controls="typography-headings">
						<span class="dashicons dashicons-editor-textcolor" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Headings', 'modern-admin-styler' ); ?></span>
					</button>
					<button type="button" class="mase-area-button" data-area="comments" role="tab" aria-selected="false" aria-controls="typography-comments">
						<span class="dashicons dashicons-admin-comments" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Comments', 'modern-admin-styler' ); ?></span>
					</button>
					<button type="button" class="mase-area-button" data-area="widgets" role="tab" aria-selected="false" aria-controls="typography-widgets">
						<span class="dashicons dashicons-welcome-widgets-menus" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Widgets', 'modern-admin-styler' ); ?></span>
					</button>
					<button type="button" class="mase-area-button" data-area="meta" role="tab" aria-selected="false" aria-controls="typography-meta">
						<span class="dashicons dashicons-info" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Meta', 'modern-admin-styler' ); ?></span>
					</button>
					<button type="button" class="mase-area-button" data-area="tables" role="tab" aria-selected="false" aria-controls="typography-tables">
						<span class="dashicons dashicons-editor-table" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Tables', 'modern-admin-styler' ); ?></span>
					</button>
					<button type="button" class="mase-area-button" data-area="notices" role="tab" aria-selected="false" aria-controls="typography-notices">
						<span class="dashicons dashicons-warning" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Notices', 'modern-admin-styler' ); ?></span>
					</button>
				</div>
			</div>

			<!-- Typography Controls (shown for all areas except headings) -->
			<div class="mase-section mase-typography-controls" id="typography-controls-general">
				<div class="mase-section-header">
					<h3><?php esc_html_e( 'Typography Properties', 'modern-admin-styler' ); ?></h3>
				</div>
				
				<table class="form-table" role="presentation">
					<tbody>
						<!-- Font Family -->
						<tr>
							<th scope="row">
								<label for="typography-font-family">
									<?php esc_html_e( 'Font Family', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<select id="typography-font-family" name="content_typography[body_text][font_family]" class="typography-font-family">
									<option value="system"><?php esc_html_e( 'System Font', 'modern-admin-styler' ); ?></option>
									<optgroup label="<?php esc_attr_e( 'Google Fonts', 'modern-admin-styler' ); ?>">
										<option value="Inter">Inter</option>
										<option value="Roboto">Roboto</option>
										<option value="Open Sans">Open Sans</option>
										<option value="Lato">Lato</option>
										<option value="Montserrat">Montserrat</option>
										<option value="Poppins">Poppins</option>
										<option value="Raleway">Raleway</option>
										<option value="Source Sans Pro">Source Sans Pro</option>
										<option value="Nunito">Nunito</option>
										<option value="PT Sans">PT Sans</option>
									</optgroup>
								</select>
								<p class="description"><?php esc_html_e( 'Choose from system fonts or Google Fonts.', 'modern-admin-styler' ); ?></p>
							</td>
						</tr>
						
						<!-- Font Size -->
						<tr>
							<th scope="row">
								<label for="typography-font-size">
									<?php esc_html_e( 'Font Size', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<div class="mase-range-control">
									<input 
										type="range" 
										id="typography-font-size"
										name="content_typography[body_text][font_size]" 
										class="typography-property"
										data-property="font_size"
										value="16"
										min="8"
										max="72"
										step="1"
										aria-describedby="typography-font-size-value"
									/>
									<input 
										type="number" 
										id="typography-font-size-value"
										class="typography-property-value small-text"
										value="16"
										min="8"
										max="72"
										step="1"
										aria-label="<?php esc_attr_e( 'Font size in pixels', 'modern-admin-styler' ); ?>"
									/>
									<span class="mase-unit">px</span>
								</div>
							</td>
						</tr>
						
						<!-- Line Height -->
						<tr>
							<th scope="row">
								<label for="typography-line-height">
									<?php esc_html_e( 'Line Height', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<div class="mase-range-control">
									<input 
										type="range" 
										id="typography-line-height"
										name="content_typography[body_text][line_height]" 
										class="typography-property"
										data-property="line_height"
										value="1.6"
										min="0.8"
										max="3.0"
										step="0.1"
										aria-describedby="typography-line-height-value"
									/>
									<input 
										type="number" 
										id="typography-line-height-value"
										class="typography-property-value small-text"
										value="1.6"
										min="0.8"
										max="3.0"
										step="0.1"
										aria-label="<?php esc_attr_e( 'Line height value', 'modern-admin-styler' ); ?>"
									/>
								</div>
							</td>
						</tr>
						
						<!-- Letter Spacing -->
						<tr>
							<th scope="row">
								<label for="typography-letter-spacing">
									<?php esc_html_e( 'Letter Spacing', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<div class="mase-range-control">
									<input 
										type="range" 
										id="typography-letter-spacing"
										name="content_typography[body_text][letter_spacing]" 
										class="typography-property"
										data-property="letter_spacing"
										value="0"
										min="-5"
										max="10"
										step="0.5"
										aria-describedby="typography-letter-spacing-value"
									/>
									<input 
										type="number" 
										id="typography-letter-spacing-value"
										class="typography-property-value small-text"
										value="0"
										min="-5"
										max="10"
										step="0.5"
										aria-label="<?php esc_attr_e( 'Letter spacing in pixels', 'modern-admin-styler' ); ?>"
									/>
									<span class="mase-unit">px</span>
								</div>
							</td>
						</tr>
						
						<!-- Word Spacing -->
						<tr>
							<th scope="row">
								<label for="typography-word-spacing">
									<?php esc_html_e( 'Word Spacing', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<div class="mase-range-control">
									<input 
										type="range" 
										id="typography-word-spacing"
										name="content_typography[body_text][word_spacing]" 
										class="typography-property"
										data-property="word_spacing"
										value="0"
										min="-5"
										max="10"
										step="0.5"
										aria-describedby="typography-word-spacing-value"
									/>
									<input 
										type="number" 
										id="typography-word-spacing-value"
										class="typography-property-value small-text"
										value="0"
										min="-5"
										max="10"
										step="0.5"
										aria-label="<?php esc_attr_e( 'Word spacing in pixels', 'modern-admin-styler' ); ?>"
									/>
									<span class="mase-unit">px</span>
								</div>
							</td>
						</tr>
						
						<!-- Font Weight -->
						<tr>
							<th scope="row">
								<label for="typography-font-weight">
									<?php esc_html_e( 'Font Weight', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<select id="typography-font-weight" name="content_typography[body_text][font_weight]" class="typography-property" data-property="font_weight">
									<option value="100"><?php esc_html_e( 'Thin (100)', 'modern-admin-styler' ); ?></option>
									<option value="300"><?php esc_html_e( 'Light (300)', 'modern-admin-styler' ); ?></option>
									<option value="400" selected><?php esc_html_e( 'Regular (400)', 'modern-admin-styler' ); ?></option>
									<option value="500"><?php esc_html_e( 'Medium (500)', 'modern-admin-styler' ); ?></option>
									<option value="600"><?php esc_html_e( 'Semi-Bold (600)', 'modern-admin-styler' ); ?></option>
									<option value="700"><?php esc_html_e( 'Bold (700)', 'modern-admin-styler' ); ?></option>
									<option value="900"><?php esc_html_e( 'Black (900)', 'modern-admin-styler' ); ?></option>
								</select>
							</td>
						</tr>
						
						<!-- Font Style -->
						<tr>
							<th scope="row">
								<label for="typography-font-style">
									<?php esc_html_e( 'Font Style', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<select id="typography-font-style" name="content_typography[body_text][font_style]" class="typography-property" data-property="font_style">
									<option value="normal" selected><?php esc_html_e( 'Normal', 'modern-admin-styler' ); ?></option>
									<option value="italic"><?php esc_html_e( 'Italic', 'modern-admin-styler' ); ?></option>
									<option value="oblique"><?php esc_html_e( 'Oblique', 'modern-admin-styler' ); ?></option>
								</select>
							</td>
						</tr>
						
						<!-- Text Transform -->
						<tr>
							<th scope="row">
								<label for="typography-text-transform">
									<?php esc_html_e( 'Text Transform', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<select id="typography-text-transform" name="content_typography[body_text][text_transform]" class="typography-property" data-property="text_transform">
									<option value="none" selected><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
									<option value="uppercase"><?php esc_html_e( 'UPPERCASE', 'modern-admin-styler' ); ?></option>
									<option value="lowercase"><?php esc_html_e( 'lowercase', 'modern-admin-styler' ); ?></option>
									<option value="capitalize"><?php esc_html_e( 'Capitalize', 'modern-admin-styler' ); ?></option>
								</select>
							</td>
						</tr>
					</tbody>
				</table>
				
				<!-- Advanced Options (Collapsible) -->
				<details class="mase-typography-advanced">
					<summary><?php esc_html_e( 'Advanced Options', 'modern-admin-styler' ); ?></summary>
					
					<table class="form-table" role="presentation">
						<tbody>
							<!-- Text Shadow -->
							<tr>
								<th scope="row">
									<label for="typography-text-shadow">
										<?php esc_html_e( 'Text Shadow', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<input 
										type="text" 
										id="typography-text-shadow"
										name="content_typography[body_text][text_shadow]" 
										class="regular-text typography-property"
										data-property="text_shadow"
										placeholder="2px 2px 4px rgba(0,0,0,0.3)"
										aria-describedby="typography-text-shadow-desc"
									/>
									<p class="description" id="typography-text-shadow-desc"><?php esc_html_e( 'CSS text-shadow value (e.g., 2px 2px 4px rgba(0,0,0,0.3)).', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<!-- Ligatures -->
							<tr>
								<th scope="row">
									<?php esc_html_e( 'Font Features', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<label>
										<input 
											type="checkbox" 
											name="content_typography[body_text][ligatures]" 
											class="typography-property"
											data-property="ligatures"
											value="1"
										/>
										<?php esc_html_e( 'Enable Ligatures', 'modern-admin-styler' ); ?>
									</label>
									<p class="description"><?php esc_html_e( 'Enable font ligatures for better typography (e.g., fi, fl).', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<!-- Drop Caps -->
							<tr>
								<th scope="row">
									<?php esc_html_e( 'Drop Caps', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<label>
										<input 
											type="checkbox" 
											name="content_typography[body_text][drop_caps]" 
											class="typography-property"
											data-property="drop_caps"
											value="1"
										/>
										<?php esc_html_e( 'Enable Drop Caps', 'modern-admin-styler' ); ?>
									</label>
									<p class="description"><?php esc_html_e( 'Add decorative drop caps to first letter of paragraphs.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</details>
			</div>

			<!-- Heading Hierarchy (shown only when Headings area is selected) -->
			<div class="mase-section mase-heading-hierarchy" id="typography-heading-hierarchy" style="display: none;">
				<div class="mase-section-header">
					<h3><?php esc_html_e( 'Heading Hierarchy', 'modern-admin-styler' ); ?></h3>
					<p class="description"><?php esc_html_e( 'Configure heading sizes using a typographic scale ratio.', 'modern-admin-styler' ); ?></p>
				</div>
				
				<table class="form-table" role="presentation">
					<tbody>
						<!-- Scale Ratio -->
						<tr>
							<th scope="row">
								<label for="heading-scale-ratio">
									<?php esc_html_e( 'Scale Ratio', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<select id="heading-scale-ratio" name="content_typography[headings][scale_ratio]" class="heading-scale-ratio">
									<option value="1.125"><?php esc_html_e( 'Minor Second (1.125)', 'modern-admin-styler' ); ?></option>
									<option value="1.200"><?php esc_html_e( 'Minor Third (1.200)', 'modern-admin-styler' ); ?></option>
									<option value="1.250" selected><?php esc_html_e( 'Major Third (1.250)', 'modern-admin-styler' ); ?></option>
									<option value="1.333"><?php esc_html_e( 'Perfect Fourth (1.333)', 'modern-admin-styler' ); ?></option>
									<option value="1.414"><?php esc_html_e( 'Augmented Fourth (1.414)', 'modern-admin-styler' ); ?></option>
									<option value="1.500"><?php esc_html_e( 'Perfect Fifth (1.500)', 'modern-admin-styler' ); ?></option>
									<option value="1.618"><?php esc_html_e( 'Golden Ratio (1.618)', 'modern-admin-styler' ); ?></option>
								</select>
								<p class="description"><?php esc_html_e( 'Ratio used to calculate heading sizes from base font size.', 'modern-admin-styler' ); ?></p>
							</td>
						</tr>
					</tbody>
				</table>
				
				<!-- Individual Heading Controls -->
				<div class="mase-heading-controls">
					<?php
					$headings = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' );
					foreach ( $headings as $heading ) :
						$heading_upper = strtoupper( $heading );
						?>
					<details class="mase-heading-control">
						<summary><?php echo esc_html( $heading_upper ); ?> <?php esc_html_e( 'Settings', 'modern-admin-styler' ); ?></summary>
						
						<table class="form-table" role="presentation">
							<tbody>
								<tr>
									<th scope="row">
										<label for="heading-<?php echo esc_attr( $heading ); ?>-font-size">
											<?php esc_html_e( 'Font Size', 'modern-admin-styler' ); ?>
										</label>
									</th>
									<td>
										<input 
											type="number" 
											id="heading-<?php echo esc_attr( $heading ); ?>-font-size"
											name="content_typography[headings][<?php echo esc_attr( $heading ); ?>][font_size]" 
											class="small-text"
											min="8"
											max="72"
											step="1"
										/>
										<span class="mase-unit">px</span>
									</td>
								</tr>
								<tr>
									<th scope="row">
										<label for="heading-<?php echo esc_attr( $heading ); ?>-font-weight">
											<?php esc_html_e( 'Font Weight', 'modern-admin-styler' ); ?>
										</label>
									</th>
									<td>
										<select id="heading-<?php echo esc_attr( $heading ); ?>-font-weight" name="content_typography[headings][<?php echo esc_attr( $heading ); ?>][font_weight]">
											<option value="400"><?php esc_html_e( 'Regular (400)', 'modern-admin-styler' ); ?></option>
											<option value="500"><?php esc_html_e( 'Medium (500)', 'modern-admin-styler' ); ?></option>
											<option value="600"><?php esc_html_e( 'Semi-Bold (600)', 'modern-admin-styler' ); ?></option>
											<option value="700" selected><?php esc_html_e( 'Bold (700)', 'modern-admin-styler' ); ?></option>
											<option value="900"><?php esc_html_e( 'Black (900)', 'modern-admin-styler' ); ?></option>
										</select>
									</td>
								</tr>
							</tbody>
						</table>
					</details>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- Google Fonts Settings -->
			<div class="mase-section">
				<div class="mase-section-header">
					<h3><?php esc_html_e( 'Google Fonts Settings', 'modern-admin-styler' ); ?></h3>
					<p class="description"><?php esc_html_e( 'Configure Google Fonts integration and performance options.', 'modern-admin-styler' ); ?></p>
				</div>
				
				<table class="form-table" role="presentation">
					<tbody>
						<!-- Enable Google Fonts -->
						<tr>
							<th scope="row">
								<label for="google-fonts-enabled">
									<?php esc_html_e( 'Enable Google Fonts', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<label class="mase-toggle-switch">
									<input 
										type="checkbox" 
										id="google-fonts-enabled"
										name="content_typography[google_fonts_enabled]" 
										value="1"
										checked
										role="switch"
										aria-checked="true"
									/>
									<span class="mase-toggle-slider" aria-hidden="true"></span>
								</label>
								<p class="description"><?php esc_html_e( 'Load fonts from Google Fonts CDN.', 'modern-admin-styler' ); ?></p>
							</td>
						</tr>
						
						<!-- Font Display Strategy -->
						<tr>
							<th scope="row">
								<label for="font-display">
									<?php esc_html_e( 'Font Display Strategy', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<select id="font-display" name="content_typography[font_display]">
									<option value="swap" selected><?php esc_html_e( 'Swap (Recommended)', 'modern-admin-styler' ); ?></option>
									<option value="block"><?php esc_html_e( 'Block', 'modern-admin-styler' ); ?></option>
									<option value="fallback"><?php esc_html_e( 'Fallback', 'modern-admin-styler' ); ?></option>
									<option value="optional"><?php esc_html_e( 'Optional', 'modern-admin-styler' ); ?></option>
								</select>
								<p class="description"><?php esc_html_e( 'Controls how fonts are displayed while loading. "Swap" shows fallback font immediately.', 'modern-admin-styler' ); ?></p>
							</td>
						</tr>
						
						<!-- Preload Fonts -->
						<tr>
							<th scope="row">
								<label for="preload-fonts">
									<?php esc_html_e( 'Preload Critical Fonts', 'modern-admin-styler' ); ?>
								</label>
							</th>
							<td>
								<input 
									type="text" 
									id="preload-fonts"
									name="content_typography[preload_fonts]" 
									class="regular-text"
									placeholder="Inter, Roboto"
									aria-describedby="preload-fonts-desc"
								/>
								<p class="description" id="preload-fonts-desc"><?php esc_html_e( 'Comma-separated list of fonts to preload for better performance.', 'modern-admin-styler' ); ?></p>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
		</div><!-- #tab-typography -->

			<!-- ============================================ -->
			<!-- EFFECTS TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-effects" data-tab-content="effects" role="tabpanel" aria-labelledby="tab-button-effects" tabindex="0">
				
				<!-- Animation Settings -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Animation Settings', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Control page transitions and animations.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="effects-page-animations">
										<?php esc_html_e( 'Page Animations', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-page-animations"
											name="effects[page_animations]" 
											value="1"
											<?php checked( $settings['effects']['page_animations'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['effects']['page_animations'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-page-animations-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-page-animations-desc"><?php esc_html_e( 'Enable smooth page transitions.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<label for="effects-animation-speed">
										<?php esc_html_e( 'Animation Speed (ms)', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<input 
										type="range" 
										id="effects-animation-speed"
										name="effects[animation_speed]" 
										value="<?php echo esc_attr( $settings['effects']['animation_speed'] ?? 300 ); ?>"
										min="100"
										max="1000"
										step="50"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['effects']['animation_speed'] ?? 300 ); ?>ms</span>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<label for="effects-microanimations">
										<?php esc_html_e( 'Micro-animations', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-microanimations"
											name="visual_effects[microanimations_enabled]" 
											value="1"
											<?php checked( $settings['visual_effects']['microanimations_enabled'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['microanimations_enabled'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-microanimations-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-microanimations-desc"><?php esc_html_e( 'Enable subtle animations on buttons and interactive elements.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Advanced Animation Controls (Task 15.1) -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Advanced Animation Controls', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Fine-tune animation behavior and performance.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<!-- Animation Speed Multiplier (Task 15.2) -->
							<tr>
								<th scope="row">
									<label for="effects-animation-speed-multiplier">
										<?php esc_html_e( 'Animation Speed Multiplier', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<div class="mase-range-wrapper">
										<input 
											type="range" 
											id="effects-animation-speed-multiplier"
											name="effects[animation_speed_multiplier]" 
											class="mase-range-input"
											value="<?php echo esc_attr( $settings['effects']['animation_speed_multiplier'] ?? 1 ); ?>"
											min="0.5"
											max="2"
											step="0.1"
											aria-describedby="effects-animation-speed-multiplier-desc"
										/>
										<span class="mase-range-value" id="animation-speed-multiplier-value"><?php echo esc_html( $settings['effects']['animation_speed_multiplier'] ?? 1 ); ?>x</span>
									</div>
									<p class="description" id="effects-animation-speed-multiplier-desc">
										<?php esc_html_e( 'Adjust the speed of all animations. 0.5x = slower, 1x = normal, 2x = faster.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>

							<!-- Animation Type Toggles (Task 15.3) -->
							<tr>
								<th scope="row">
									<?php esc_html_e( 'Animation Types', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<fieldset>
										<legend class="screen-reader-text"><?php esc_html_e( 'Select which animation types to enable', 'modern-admin-styler' ); ?></legend>
										
										<div class="mase-setting-row">
											<label class="mase-toggle-switch">
												<input 
													type="checkbox" 
													id="effects-hover-animations"
													name="effects[hover_animations]" 
													value="1"
													<?php checked( $settings['effects']['hover_animations'] ?? true, true ); ?>
													role="switch"
													aria-checked="<?php echo ( $settings['effects']['hover_animations'] ?? true ) ? 'true' : 'false'; ?>"
												/>
												<span class="mase-toggle-slider" aria-hidden="true"></span>
											</label>
											<label for="effects-hover-animations" style="margin-left: 12px;">
												<?php esc_html_e( 'Hover Animations', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<p class="description" style="margin-top: 8px; margin-bottom: 16px;">
											<?php esc_html_e( 'Enable animations when hovering over elements.', 'modern-admin-styler' ); ?>
										</p>

										<div class="mase-setting-row">
											<label class="mase-toggle-switch">
												<input 
													type="checkbox" 
													id="effects-transition-animations"
													name="effects[transition_animations]" 
													value="1"
													<?php checked( $settings['effects']['transition_animations'] ?? true, true ); ?>
													role="switch"
													aria-checked="<?php echo ( $settings['effects']['transition_animations'] ?? true ) ? 'true' : 'false'; ?>"
												/>
												<span class="mase-toggle-slider" aria-hidden="true"></span>
											</label>
											<label for="effects-transition-animations" style="margin-left: 12px;">
												<?php esc_html_e( 'Transition Animations', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<p class="description" style="margin-top: 8px; margin-bottom: 16px;">
											<?php esc_html_e( 'Enable smooth transitions between states.', 'modern-admin-styler' ); ?>
										</p>

										<div class="mase-setting-row">
											<label class="mase-toggle-switch">
												<input 
													type="checkbox" 
													id="effects-background-animations"
													name="effects[background_animations]" 
													value="1"
													<?php checked( $settings['effects']['background_animations'] ?? true, true ); ?>
													role="switch"
													aria-checked="<?php echo ( $settings['effects']['background_animations'] ?? true ) ? 'true' : 'false'; ?>"
												/>
												<span class="mase-toggle-slider" aria-hidden="true"></span>
											</label>
											<label for="effects-background-animations" style="margin-left: 12px;">
												<?php esc_html_e( 'Background Animations', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<p class="description" style="margin-top: 8px;">
											<?php esc_html_e( 'Enable animated backgrounds and particles.', 'modern-admin-styler' ); ?>
										</p>
									</fieldset>
								</td>
							</tr>

							<!-- Performance Mode Toggle (Task 15.4) -->
							<tr>
								<th scope="row">
									<label for="effects-performance-mode-advanced">
										<?php esc_html_e( 'Performance Mode', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-performance-mode-advanced"
											name="effects[performance_mode_advanced]" 
											value="1"
											<?php checked( $settings['effects']['performance_mode_advanced'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['effects']['performance_mode_advanced'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-performance-mode-advanced-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-performance-mode-advanced-desc">
										<?php esc_html_e( 'Disable expensive effects like backdrop-filter, particle systems, and complex animations for better performance.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>

							<!-- Respect prefers-reduced-motion (Task 15.5) -->
							<tr>
								<th scope="row">
									<label for="effects-respect-reduced-motion">
										<?php esc_html_e( 'Respect System Preference', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-respect-reduced-motion"
											name="effects[respect_reduced_motion]" 
											value="1"
											<?php checked( $settings['effects']['respect_reduced_motion'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['effects']['respect_reduced_motion'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-respect-reduced-motion-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-respect-reduced-motion-desc">
										<?php esc_html_e( 'Automatically disable animations when the system "Reduce Motion" preference is enabled (recommended for accessibility).', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Hover Effects -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Hover Effects', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize hover interactions.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="effects-hover-effects">
										<?php esc_html_e( 'Enable Hover Effects', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-hover-effects"
											name="effects[hover_effects]" 
											value="1"
											<?php checked( $settings['effects']['hover_effects'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['effects']['hover_effects'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-hover-effects-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-hover-effects-desc"><?php esc_html_e( 'Enable hover effects on menu items and buttons.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Advanced Visual Effects -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Advanced Visual Effects', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Experimental effects that may impact performance.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="effects-particle-system">
										<?php esc_html_e( 'Particle System', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-particle-system"
											name="visual_effects[particle_system]" 
											value="1"
											<?php checked( $settings['visual_effects']['particle_system'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['particle_system'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-particle-system-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-particle-system-desc"><?php esc_html_e( 'Add animated particles to the background (may impact performance).', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<label for="effects-3d-effects">
										<?php esc_html_e( '3D Effects', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-3d-effects"
											name="visual_effects[3d_effects]" 
											value="1"
											<?php checked( $settings['visual_effects']['3d_effects'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['3d_effects'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-3d-effects-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-3d-effects-desc"><?php esc_html_e( 'Enable 3D transforms and perspective effects.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<label for="effects-sound-effects">
										<?php esc_html_e( 'Sound Effects', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-sound-effects"
											name="visual_effects[sound_effects]" 
											value="1"
											<?php checked( $settings['visual_effects']['sound_effects'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['visual_effects']['sound_effects'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-sound-effects-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-sound-effects-desc"><?php esc_html_e( 'Play subtle sound effects on interactions.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Performance Mode -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Performance Mode', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Optimize for performance by disabling resource-intensive effects.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="effects-performance-mode">
										<?php esc_html_e( 'Enable Performance Mode', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-performance-mode"
											name="effects[performance_mode]" 
											value="1"
											<?php checked( $settings['effects']['performance_mode'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['effects']['performance_mode'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-performance-mode-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-performance-mode-desc"><?php esc_html_e( 'Disable all animations and effects for maximum performance.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<label for="effects-focus-mode">
										<?php esc_html_e( 'Focus Mode', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="effects-focus-mode"
											name="effects[focus_mode]" 
											value="1"
											<?php checked( $settings['effects']['focus_mode'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['effects']['focus_mode'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="effects-focus-mode-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="effects-focus-mode-desc"><?php esc_html_e( 'Hide distractions and focus on content.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
				
			</div><!-- #tab-effects -->

			<!-- ============================================ -->
			<!-- TEMPLATES TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-templates" data-tab-content="templates" role="tabpanel" aria-labelledby="tab-button-templates" tabindex="0">
				
				<!-- Full Template Gallery -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Template Gallery', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Browse and apply complete design templates. Each template includes colors, typography, and visual effects.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<!-- Search and Filter (Requirement 27.1) -->
					<div class="mase-template-search-container">
						<div class="mase-md3-search-field">
							<span class="mase-search-icon dashicons dashicons-search" aria-hidden="true"></span>
							<input 
								type="text" 
								id="mase-template-search"
								class="mase-search-input"
								placeholder="<?php esc_attr_e( 'Search templates...', 'modern-admin-styler' ); ?>"
								aria-label="<?php esc_attr_e( 'Search templates', 'modern-admin-styler' ); ?>"
								autocomplete="off"
							/>
							<button 
								type="button" 
								class="mase-search-clear" 
								id="mase-template-search-clear"
								aria-label="<?php esc_attr_e( 'Clear search', 'modern-admin-styler' ); ?>"
								style="display: none;">
								<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
							</button>
						</div>
					</div>
					
					<div class="mase-template-gallery">
						<?php foreach ( $templates as $template_id => $template ) : ?>
							<div class="mase-template-card <?php echo ( $settings['templates']['current'] === $template_id ) ? 'active' : ''; ?>" 
								data-template="<?php echo esc_attr( $template_id ); ?>" 
								data-template-id="<?php echo esc_attr( $template_id ); ?>" 
								data-template-primary="<?php echo esc_attr( $template['colors']['primary'] ?? '#6750a4' ); ?>"
								data-template-secondary="<?php echo esc_attr( $template['colors']['secondary'] ?? '#625b71' ); ?>"
								role="article" 
								aria-label="<?php echo esc_attr( $template['name'] ); ?>">
								
								<!-- Artistic Header Gradient Container (Requirements 3.1, 3.3) -->
								<div class="mase-template-header" aria-hidden="true">
									<!-- Mini-preview elements (Requirements 23.1, 23.2, 23.3, 23.4) -->
									<div class="mase-template-preview">
										<!-- Mini Admin Bar with shimmer animation -->
										<div class="mase-template-minibar"></div>
										
										<!-- Mini Menu Items with pulse animation -->
										<div class="mase-template-minimenu">
											<div class="mase-template-menuitem"></div>
											<div class="mase-template-menuitem"></div>
											<div class="mase-template-menuitem"></div>
										</div>
									</div>
								</div>
								
								<!-- Template Content -->
								<div class="mase-template-content">
									<!-- Template Name (Requirement 3.1) -->
									<h3 class="mase-template-name"><?php echo esc_html( $template['name'] ); ?></h3>
									<p class="mase-template-description"><?php echo esc_html( $template['description'] ); ?></p>
									
									<?php if ( ! empty( $template['is_custom'] ) ) : ?>
										<span class="mase-custom-badge"><?php esc_html_e( 'Custom', 'modern-admin-styler' ); ?></span>
									<?php endif; ?>
									
									<?php if ( $settings['templates']['current'] === $template_id ) : ?>
										<span class="mase-active-badge"><?php esc_html_e( 'Active', 'modern-admin-styler' ); ?></span>
									<?php endif; ?>
								</div>
								
								<!-- Apply Button (Requirement 3.1) -->
								<div class="mase-template-actions">
									<button type="button" class="button button-primary mase-template-apply-btn" data-template-id="<?php echo esc_attr( $template_id ); ?>">
										<?php esc_html_e( 'Apply', 'modern-admin-styler' ); ?>
									</button>
									<?php if ( ! empty( $template['is_custom'] ) ) : ?>
										<button type="button" class="button button-link-delete mase-template-delete-btn" data-template-id="<?php echo esc_attr( $template_id ); ?>">
											<?php esc_html_e( 'Delete', 'modern-admin-styler' ); ?>
										</button>
									<?php endif; ?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
					
					<!-- Empty State (Requirement 27.4) -->
					<div class="mase-template-empty-state" id="mase-template-empty-state" style="display: none;" role="status">
						<div class="mase-empty-state-icon" aria-hidden="true">
							<span class="dashicons dashicons-search"></span>
						</div>
						<h3 class="mase-empty-state-title"><?php esc_html_e( 'No templates found', 'modern-admin-styler' ); ?></h3>
						<p class="mase-empty-state-message"><?php esc_html_e( 'Try adjusting your search terms or clear the search to see all templates.', 'modern-admin-styler' ); ?></p>
						<button type="button" class="button button-secondary mase-empty-state-clear" id="mase-empty-state-clear">
							<?php esc_html_e( 'Clear Search', 'modern-admin-styler' ); ?>
						</button>
					</div>
				</div>

				<!-- Save Custom Template -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Save Custom Template', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Save your current settings as a custom template for future use.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="custom-template-name">
										<?php esc_html_e( 'Template Name', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<input 
										type="text" 
										id="custom-template-name"
										class="regular-text"
										placeholder="<?php esc_attr_e( 'My Custom Template', 'modern-admin-styler' ); ?>"
									/>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<label for="custom-template-description">
										<?php esc_html_e( 'Description', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<textarea 
										id="custom-template-description"
										class="large-text"
										rows="3"
										placeholder="<?php esc_attr_e( 'Describe your template...', 'modern-admin-styler' ); ?>"
									></textarea>
								</td>
							</tr>
							
							<tr>
								<th scope="row"></th>
								<td>
									<button type="button" id="mase-save-custom-template" class="button button-primary">
										<?php esc_html_e( 'Save as Template', 'modern-admin-styler' ); ?>
									</button>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Theme Intensity Controls (Requirement 2.1) -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Theme Intensity Controls', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Adjust the intensity of visual effects for all themes. Control animation speeds, blur effects, and glow intensity.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<div class="mase-section-card">
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="theme-intensity-level">
										<?php esc_html_e( 'Intensity Level', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<div class="mase-intensity-control">
										<input 
											type="range" 
											id="theme-intensity-level"
											name="templates[intensity_level]" 
											min="1"
											max="3"
											step="1"
											value="<?php echo esc_attr( $settings['templates']['intensity_level'] ?? 2 ); ?>"
											aria-describedby="theme-intensity-level-desc"
											aria-valuemin="1"
											aria-valuemax="3"
											aria-valuenow="<?php echo esc_attr( $settings['templates']['intensity_level'] ?? 2 ); ?>"
											aria-valuetext="<?php 
												$intensity = $settings['templates']['intensity_level'] ?? 2;
												echo esc_attr( $intensity == 1 ? __( 'Low', 'modern-admin-styler' ) : ( $intensity == 3 ? __( 'High', 'modern-admin-styler' ) : __( 'Medium', 'modern-admin-styler' ) ) );
											?>"
										/>
										<div class="mase-intensity-labels">
											<span class="mase-intensity-label" data-value="1">
												<?php esc_html_e( 'Low', 'modern-admin-styler' ); ?>
											</span>
											<span class="mase-intensity-label" data-value="2">
												<?php esc_html_e( 'Medium', 'modern-admin-styler' ); ?>
											</span>
											<span class="mase-intensity-label" data-value="3">
												<?php esc_html_e( 'High', 'modern-admin-styler' ); ?>
											</span>
										</div>
									</div>
									<p class="description" id="theme-intensity-level-desc">
										<?php esc_html_e( 'Low: Subtle effects (50% animation speed, 30% less blur). Medium: Default effects. High: Enhanced effects (30% faster animations, 50% more glow).', 'modern-admin-styler' ); ?>
									</p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label>
										<?php esc_html_e( 'Current Settings', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<div class="mase-intensity-preview">
										<div class="mase-intensity-stat">
											<span class="mase-stat-label"><?php esc_html_e( 'Animation Speed:', 'modern-admin-styler' ); ?></span>
											<span class="mase-stat-value" id="intensity-animation-speed">1x</span>
										</div>
										<div class="mase-intensity-stat">
											<span class="mase-stat-label"><?php esc_html_e( 'Blur Amount:', 'modern-admin-styler' ); ?></span>
											<span class="mase-stat-value" id="intensity-blur-amount">100%</span>
										</div>
										<div class="mase-intensity-stat">
											<span class="mase-stat-label"><?php esc_html_e( 'Glow Intensity:', 'modern-admin-styler' ); ?></span>
											<span class="mase-stat-value" id="intensity-glow-intensity">100%</span>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div><!-- #tab-templates -->

			<!-- ============================================ -->
			<!-- LOGIN PAGE TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-login" data-tab-content="login" role="tabpanel" aria-labelledby="tab-button-login" tabindex="0">
				
				<!-- Logo Settings Section -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Custom Logo', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Upload a custom logo to replace the default WordPress logo on the login page.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-logo-enabled">
										<?php esc_html_e( 'Enable Custom Logo', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="login-logo-enabled"
											name="login_customization[logo_enabled]" 
											value="1"
											<?php checked( $settings['login_customization']['logo_enabled'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['login_customization']['logo_enabled'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="login-logo-enabled-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="login-logo-enabled-desc"><?php esc_html_e( 'Replace the WordPress logo with your own branding.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-conditional-group" data-depends-on="login-logo-enabled" style="display: <?php echo ( $settings['login_customization']['logo_enabled'] ?? false ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-logo-upload">
											<?php esc_html_e( 'Logo Image', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<div class="mase-file-upload-wrapper">
											<input type="hidden" id="login-logo-url" name="login_customization[logo_url]" value="<?php echo esc_attr( $settings['login_customization']['logo_url'] ?? '' ); ?>" />
											<button type="button" class="button button-secondary mase-upload-btn" data-upload-type="login-logo" aria-label="<?php esc_attr_e( 'Upload logo image', 'modern-admin-styler' ); ?>">
												<span class="dashicons dashicons-upload"></span>
												<?php esc_html_e( 'Upload Logo', 'modern-admin-styler' ); ?>
											</button>
											<?php if ( ! empty( $settings['login_customization']['logo_url'] ) ) : ?>
												<button type="button" class="button button-link-delete mase-remove-upload" data-target="login-logo-url" aria-label="<?php esc_attr_e( 'Remove logo', 'modern-admin-styler' ); ?>">
													<?php esc_html_e( 'Remove', 'modern-admin-styler' ); ?>
												</button>
											<?php endif; ?>
										</div>
										<?php if ( ! empty( $settings['login_customization']['logo_url'] ) ) : ?>
											<div class="mase-image-preview" id="login-logo-preview">
												<img src="<?php echo esc_url( $settings['login_customization']['logo_url'] ); ?>" alt="<?php esc_attr_e( 'Login logo preview', 'modern-admin-styler' ); ?>" style="max-width: 200px; max-height: 100px;" />
											</div>
										<?php endif; ?>
										<p class="description"><?php esc_html_e( 'Supported formats: PNG, JPG, SVG. Maximum size: 2MB.', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-logo-width">
											<?php esc_html_e( 'Logo Width (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="login-logo-width"
											name="login_customization[logo_width]" 
											min="50"
											max="400"
											step="1"
											value="<?php echo esc_attr( $settings['login_customization']['logo_width'] ?? 84 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['logo_width'] ?? 84 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-logo-height">
											<?php esc_html_e( 'Logo Height (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="login-logo-height"
											name="login_customization[logo_height]" 
											min="50"
											max="400"
											step="1"
											value="<?php echo esc_attr( $settings['login_customization']['logo_height'] ?? 84 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['logo_height'] ?? 84 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-logo-link-url">
											<?php esc_html_e( 'Logo Link URL', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="url" 
											id="login-logo-link-url"
											name="login_customization[logo_link_url]" 
											class="regular-text"
											value="<?php echo esc_attr( $settings['login_customization']['logo_link_url'] ?? '' ); ?>"
											placeholder="<?php esc_attr_e( 'https://yoursite.com', 'modern-admin-styler' ); ?>"
										/>
										<p class="description"><?php esc_html_e( 'Optional. Leave empty to link to WordPress.org (default).', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Background Settings Section -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Background Customization', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the login page background with colors, images, or gradients.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-background-type">
										<?php esc_html_e( 'Background Type', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="login-background-type" name="login_customization[background_type]">
										<option value="color" <?php selected( $settings['login_customization']['background_type'] ?? 'color', 'color' ); ?>>
											<?php esc_html_e( 'Solid Color', 'modern-admin-styler' ); ?>
										</option>
										<option value="image" <?php selected( $settings['login_customization']['background_type'] ?? 'color', 'image' ); ?>>
											<?php esc_html_e( 'Image', 'modern-admin-styler' ); ?>
										</option>
										<option value="gradient" <?php selected( $settings['login_customization']['background_type'] ?? 'color', 'gradient' ); ?>>
											<?php esc_html_e( 'Gradient', 'modern-admin-styler' ); ?>
										</option>
									</select>
								</div>
							</div>
							
							<!-- Solid Color Background -->
							<div class="mase-conditional-group" data-depends-on="login-background-type" data-value="color" style="display: <?php echo ( ! isset( $settings['login_customization']['background_type'] ) || $settings['login_customization']['background_type'] === 'color' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-background-color">
											<?php esc_html_e( 'Background Color', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="login-background-color"
											name="login_customization[background_color]" 
											class="mase-color-picker"
											value="<?php echo esc_attr( $settings['login_customization']['background_color'] ?? '#f0f0f1' ); ?>"
											data-default-color="#f0f0f1"
										/>
									</div>
								</div>
							</div>
							
							<!-- Image Background -->
							<div class="mase-conditional-group" data-depends-on="login-background-type" data-value="image" style="display: <?php echo ( isset( $settings['login_customization']['background_type'] ) && $settings['login_customization']['background_type'] === 'image' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-background-image">
											<?php esc_html_e( 'Background Image', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<div class="mase-file-upload-wrapper">
											<input type="hidden" id="login-background-image" name="login_customization[background_image]" value="<?php echo esc_attr( $settings['login_customization']['background_image'] ?? '' ); ?>" />
											<button type="button" class="button button-secondary mase-upload-btn" data-upload-type="login-background" aria-label="<?php esc_attr_e( 'Upload background image', 'modern-admin-styler' ); ?>">
												<span class="dashicons dashicons-upload"></span>
												<?php esc_html_e( 'Upload Image', 'modern-admin-styler' ); ?>
											</button>
											<?php if ( ! empty( $settings['login_customization']['background_image'] ) ) : ?>
												<button type="button" class="button button-link-delete mase-remove-upload" data-target="login-background-image" aria-label="<?php esc_attr_e( 'Remove background image', 'modern-admin-styler' ); ?>">
													<?php esc_html_e( 'Remove', 'modern-admin-styler' ); ?>
												</button>
											<?php endif; ?>
										</div>
										<?php if ( ! empty( $settings['login_customization']['background_image'] ) ) : ?>
											<div class="mase-image-preview" id="login-background-preview">
												<img src="<?php echo esc_url( $settings['login_customization']['background_image'] ); ?>" alt="<?php esc_attr_e( 'Background preview', 'modern-admin-styler' ); ?>" style="max-width: 200px; max-height: 100px;" />
											</div>
										<?php endif; ?>
										<p class="description"><?php esc_html_e( 'Supported formats: PNG, JPG. Maximum size: 5MB.', 'modern-admin-styler' ); ?></p>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-background-size">
											<?php esc_html_e( 'Background Size', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<select id="login-background-size" name="login_customization[background_size]">
											<option value="cover" <?php selected( $settings['login_customization']['background_size'] ?? 'cover', 'cover' ); ?>>
												<?php esc_html_e( 'Cover', 'modern-admin-styler' ); ?>
											</option>
											<option value="contain" <?php selected( $settings['login_customization']['background_size'] ?? 'cover', 'contain' ); ?>>
												<?php esc_html_e( 'Contain', 'modern-admin-styler' ); ?>
											</option>
											<option value="auto" <?php selected( $settings['login_customization']['background_size'] ?? 'cover', 'auto' ); ?>>
												<?php esc_html_e( 'Auto', 'modern-admin-styler' ); ?>
											</option>
										</select>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-background-opacity">
											<?php esc_html_e( 'Background Opacity', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="login-background-opacity"
											name="login_customization[background_opacity]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['login_customization']['background_opacity'] ?? 100 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['background_opacity'] ?? 100 ); ?>%</span>
									</div>
								</div>
							</div>
							
							<!-- Gradient Background -->
							<div class="mase-conditional-group" data-depends-on="login-background-type" data-value="gradient" style="display: <?php echo ( isset( $settings['login_customization']['background_type'] ) && $settings['login_customization']['background_type'] === 'gradient' ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-gradient-type">
											<?php esc_html_e( 'Gradient Type', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<select id="login-gradient-type" name="login_customization[gradient_type]">
											<option value="linear" <?php selected( $settings['login_customization']['gradient_type'] ?? 'linear', 'linear' ); ?>>
												<?php esc_html_e( 'Linear', 'modern-admin-styler' ); ?>
											</option>
											<option value="radial" <?php selected( $settings['login_customization']['gradient_type'] ?? 'linear', 'radial' ); ?>>
												<?php esc_html_e( 'Radial', 'modern-admin-styler' ); ?>
											</option>
										</select>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-gradient-angle">
											<?php esc_html_e( 'Gradient Angle', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="login-gradient-angle"
											name="login_customization[gradient_angle]" 
											min="0"
											max="360"
											step="1"
											value="<?php echo esc_attr( $settings['login_customization']['gradient_angle'] ?? 135 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['gradient_angle'] ?? 135 ); ?>°</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-gradient-color-1">
											<?php esc_html_e( 'Color Stop 1', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="login-gradient-color-1"
											name="login_customization[gradient_colors][0][color]" 
											class="mase-color-picker"
											value="<?php echo esc_attr( $settings['login_customization']['gradient_colors'][0]['color'] ?? '#667eea' ); ?>"
											data-default-color="#667eea"
										/>
										<input 
											type="hidden" 
											name="login_customization[gradient_colors][0][position]" 
											value="0"
										/>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-gradient-color-2">
											<?php esc_html_e( 'Color Stop 2', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="text" 
											id="login-gradient-color-2"
											name="login_customization[gradient_colors][1][color]" 
											class="mase-color-picker"
											value="<?php echo esc_attr( $settings['login_customization']['gradient_colors'][1]['color'] ?? '#764ba2' ); ?>"
											data-default-color="#764ba2"
										/>
										<input 
											type="hidden" 
											name="login_customization[gradient_colors][1][position]" 
											value="100"
										/>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Form Styling Section -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Login Form Styling', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the appearance of the login form container and input fields.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-form-bg-color">
										<?php esc_html_e( 'Form Background Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="login-form-bg-color"
										name="login_customization[form_bg_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['login_customization']['form_bg_color'] ?? '#ffffff' ); ?>"
										data-default-color="#ffffff"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-form-border-color">
										<?php esc_html_e( 'Form Border Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="login-form-border-color"
										name="login_customization[form_border_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['login_customization']['form_border_color'] ?? '#c3c4c7' ); ?>"
										data-default-color="#c3c4c7"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-form-text-color">
										<?php esc_html_e( 'Form Text Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="login-form-text-color"
										name="login_customization[form_text_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['login_customization']['form_text_color'] ?? '#2c3338' ); ?>"
										data-default-color="#2c3338"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-form-focus-color">
										<?php esc_html_e( 'Focus State Color', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="text" 
										id="login-form-focus-color"
										name="login_customization[form_focus_color]" 
										class="mase-color-picker"
										value="<?php echo esc_attr( $settings['login_customization']['form_focus_color'] ?? '#2271b1' ); ?>"
										data-default-color="#2271b1"
									/>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-form-border-radius">
										<?php esc_html_e( 'Border Radius (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="login-form-border-radius"
										name="login_customization[form_border_radius]" 
										min="0"
										max="25"
										step="1"
										value="<?php echo esc_attr( $settings['login_customization']['form_border_radius'] ?? 0 ); ?>"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['form_border_radius'] ?? 0 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-form-box-shadow">
										<?php esc_html_e( 'Box Shadow', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="login-form-box-shadow" name="login_customization[form_box_shadow]">
										<option value="none" <?php selected( $settings['login_customization']['form_box_shadow'] ?? 'default', 'none' ); ?>>
											<?php esc_html_e( 'None', 'modern-admin-styler' ); ?>
										</option>
										<option value="default" <?php selected( $settings['login_customization']['form_box_shadow'] ?? 'default', 'default' ); ?>>
											<?php esc_html_e( 'Default', 'modern-admin-styler' ); ?>
										</option>
										<option value="subtle" <?php selected( $settings['login_customization']['form_box_shadow'] ?? 'default', 'subtle' ); ?>>
											<?php esc_html_e( 'Subtle', 'modern-admin-styler' ); ?>
										</option>
										<option value="medium" <?php selected( $settings['login_customization']['form_box_shadow'] ?? 'default', 'medium' ); ?>>
											<?php esc_html_e( 'Medium', 'modern-admin-styler' ); ?>
										</option>
										<option value="strong" <?php selected( $settings['login_customization']['form_box_shadow'] ?? 'default', 'strong' ); ?>>
											<?php esc_html_e( 'Strong', 'modern-admin-styler' ); ?>
										</option>
									</select>
								</div>
							</div>
							
							<!-- Glassmorphism Effect -->
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-glassmorphism-enabled">
										<?php esc_html_e( 'Glassmorphism Effect', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="login-glassmorphism-enabled"
											name="login_customization[glassmorphism_enabled]" 
											value="1"
											<?php checked( $settings['login_customization']['glassmorphism_enabled'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['login_customization']['glassmorphism_enabled'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="login-glassmorphism-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="login-glassmorphism-desc"><?php esc_html_e( 'Apply frosted glass effect with backdrop blur.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-conditional-group" data-depends-on="login-glassmorphism-enabled" style="display: <?php echo ( $settings['login_customization']['glassmorphism_enabled'] ?? false ) ? 'block' : 'none'; ?>;">
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-glassmorphism-blur">
											<?php esc_html_e( 'Blur Intensity (px)', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="login-glassmorphism-blur"
											name="login_customization[glassmorphism_blur]" 
											min="0"
											max="50"
											step="1"
											value="<?php echo esc_attr( $settings['login_customization']['glassmorphism_blur'] ?? 10 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['glassmorphism_blur'] ?? 10 ); ?>px</span>
									</div>
								</div>
								
								<div class="mase-setting-row">
									<div class="mase-setting-label">
										<label for="login-glassmorphism-opacity">
											<?php esc_html_e( 'Opacity', 'modern-admin-styler' ); ?>
										</label>
									</div>
									<div class="mase-setting-control">
										<input 
											type="range" 
											id="login-glassmorphism-opacity"
											name="login_customization[glassmorphism_opacity]" 
											min="0"
											max="100"
											step="1"
											value="<?php echo esc_attr( $settings['login_customization']['glassmorphism_opacity'] ?? 80 ); ?>"
										/>
										<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['glassmorphism_opacity'] ?? 80 ); ?>%</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Typography Section -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Typography', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Customize the typography of the login form labels and input fields.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-label-font-family">
										<?php esc_html_e( 'Label Font Family', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="login-label-font-family" name="login_customization[label_font_family]">
										<option value="system" <?php selected( $settings['login_customization']['label_font_family'] ?? 'system', 'system' ); ?>>
											<?php esc_html_e( 'System Default', 'modern-admin-styler' ); ?>
										</option>
										<option value="Arial, sans-serif" <?php selected( $settings['login_customization']['label_font_family'] ?? 'system', 'Arial, sans-serif' ); ?>>Arial</option>
										<option value="Helvetica, sans-serif" <?php selected( $settings['login_customization']['label_font_family'] ?? 'system', 'Helvetica, sans-serif' ); ?>>Helvetica</option>
										<option value="Georgia, serif" <?php selected( $settings['login_customization']['label_font_family'] ?? 'system', 'Georgia, serif' ); ?>>Georgia</option>
									</select>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-label-font-size">
										<?php esc_html_e( 'Label Font Size (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="login-label-font-size"
										name="login_customization[label_font_size]" 
										min="10"
										max="24"
										step="1"
										value="<?php echo esc_attr( $settings['login_customization']['label_font_size'] ?? 14 ); ?>"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['label_font_size'] ?? 14 ); ?>px</span>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-label-font-weight">
										<?php esc_html_e( 'Label Font Weight', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="login-label-font-weight" name="login_customization[label_font_weight]">
										<option value="300" <?php selected( $settings['login_customization']['label_font_weight'] ?? 400, 300 ); ?>>300 (Light)</option>
										<option value="400" <?php selected( $settings['login_customization']['label_font_weight'] ?? 400, 400 ); ?>>400 (Normal)</option>
										<option value="500" <?php selected( $settings['login_customization']['label_font_weight'] ?? 400, 500 ); ?>>500 (Medium)</option>
										<option value="600" <?php selected( $settings['login_customization']['label_font_weight'] ?? 400, 600 ); ?>>600 (Semi-Bold)</option>
										<option value="700" <?php selected( $settings['login_customization']['label_font_weight'] ?? 400, 700 ); ?>>700 (Bold)</option>
									</select>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-input-font-family">
										<?php esc_html_e( 'Input Font Family', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<select id="login-input-font-family" name="login_customization[input_font_family]">
										<option value="system" <?php selected( $settings['login_customization']['input_font_family'] ?? 'system', 'system' ); ?>>
											<?php esc_html_e( 'System Default', 'modern-admin-styler' ); ?>
										</option>
										<option value="Arial, sans-serif" <?php selected( $settings['login_customization']['input_font_family'] ?? 'system', 'Arial, sans-serif' ); ?>>Arial</option>
										<option value="Helvetica, sans-serif" <?php selected( $settings['login_customization']['input_font_family'] ?? 'system', 'Helvetica, sans-serif' ); ?>>Helvetica</option>
										<option value="Georgia, serif" <?php selected( $settings['login_customization']['input_font_family'] ?? 'system', 'Georgia, serif' ); ?>>Georgia</option>
									</select>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-input-font-size">
										<?php esc_html_e( 'Input Font Size (px)', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<input 
										type="range" 
										id="login-input-font-size"
										name="login_customization[input_font_size]" 
										min="16"
										max="32"
										step="1"
										value="<?php echo esc_attr( $settings['login_customization']['input_font_size'] ?? 24 ); ?>"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['login_customization']['input_font_size'] ?? 24 ); ?>px</span>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Additional Options Section -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h2><?php esc_html_e( 'Additional Options', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Additional customization options for the login page.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-hide-wp-branding">
										<?php esc_html_e( 'Hide WordPress Branding', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="login-hide-wp-branding"
											name="login_customization[hide_wp_branding]" 
											value="1"
											<?php checked( $settings['login_customization']['hide_wp_branding'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['login_customization']['hide_wp_branding'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="login-hide-wp-branding-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="login-hide-wp-branding-desc"><?php esc_html_e( 'Hide "Powered by WordPress" and "Back to" links.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-footer-text">
										<?php esc_html_e( 'Custom Footer Text', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<textarea 
										id="login-footer-text"
										name="login_customization[footer_text]" 
										class="large-text"
										rows="3"
										placeholder="<?php esc_attr_e( 'Enter custom footer text (HTML allowed)...', 'modern-admin-styler' ); ?>"
									><?php echo esc_textarea( $settings['login_customization']['footer_text'] ?? '' ); ?></textarea>
									<p class="description"><?php esc_html_e( 'Optional custom text to display in the login page footer. HTML is allowed.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="login-custom-css">
										<?php esc_html_e( 'Custom CSS', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<textarea 
										id="login-custom-css"
										name="login_customization[custom_css]" 
										class="large-text code"
										rows="10"
										placeholder="<?php esc_attr_e( '/* Add custom CSS here */', 'modern-admin-styler' ); ?>"
									><?php echo esc_textarea( $settings['login_customization']['custom_css'] ?? '' ); ?></textarea>
									<p class="description"><?php esc_html_e( 'Add custom CSS to further customize the login page appearance.', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div><!-- #tab-login -->

			<!-- ============================================ -->
			<!-- ADVANCED TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-advanced" data-tab-content="advanced" role="tabpanel" aria-labelledby="tab-button-advanced" tabindex="0">
				
				<!-- Custom CSS -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Custom CSS', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Add custom CSS to further customize your admin interface.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="advanced-custom-css">
										<?php esc_html_e( 'Custom CSS Code', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<textarea 
										id="advanced-custom-css"
										name="advanced[custom_css]" 
										class="large-text code"
										rows="10"
										placeholder="/* Add your custom CSS here */"
									><?php echo esc_textarea( $settings['advanced']['custom_css'] ?? '' ); ?></textarea>
									<p class="description"><?php esc_html_e( 'CSS will be sanitized and appended to generated styles.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Custom JavaScript -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Custom JavaScript', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Add custom JavaScript for advanced functionality.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="advanced-custom-js">
										<?php esc_html_e( 'Custom JavaScript Code', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<textarea 
										id="advanced-custom-js"
										name="advanced[custom_js]" 
										class="large-text code"
										rows="10"
										placeholder="// Add your custom JavaScript here"
									><?php echo esc_textarea( $settings['advanced']['custom_js'] ?? '' ); ?></textarea>
									<p class="description">
										<strong><?php esc_html_e( 'Warning:', 'modern-admin-styler' ); ?></strong> 
										<?php esc_html_e( 'Custom JavaScript can break your admin interface. Use with caution.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Dark Mode Settings (Requirements 10.1-10.7) -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Dark Mode Settings', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Configure the global dark/light mode toggle feature with FAB button and keyboard shortcuts.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<!-- Enable/Disable Toggle (Requirement 10.1) -->
							<tr>
								<th scope="row">
									<label for="dark-mode-enabled">
										<?php esc_html_e( 'Enable Dark Mode Toggle', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="dark-mode-enabled"
											name="dark_light_toggle[enabled]" 
											value="1"
											<?php checked( $settings['dark_light_toggle']['enabled'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['dark_light_toggle']['enabled'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="dark-mode-enabled-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="dark-mode-enabled-desc">
										<?php esc_html_e( 'Enable the floating action button (FAB) for quick dark/light mode switching.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
							
							<!-- Respect System Preference (Requirement 10.2) -->
							<tr class="mase-conditional" data-depends-on="dark-mode-enabled">
								<th scope="row">
									<label for="dark-mode-respect-system">
										<?php esc_html_e( 'Respect System Preference', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="dark-mode-respect-system"
											name="dark_light_toggle[respect_system_preference]" 
											value="1"
											<?php checked( $settings['dark_light_toggle']['respect_system_preference'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['dark_light_toggle']['respect_system_preference'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="dark-mode-respect-system-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="dark-mode-respect-system-desc">
										<?php esc_html_e( 'Automatically detect and apply OS dark mode preference on first load.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
							
							<!-- Light Palette Selector (Requirement 10.3) -->
							<tr class="mase-conditional" data-depends-on="dark-mode-enabled">
								<th scope="row">
									<label for="dark-mode-light-palette">
										<?php esc_html_e( 'Light Mode Palette', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<select id="dark-mode-light-palette" name="dark_light_toggle[light_palette]" class="regular-text">
										<?php foreach ( $palettes as $palette_id => $palette ) : ?>
											<?php if ( ( $palette['type'] ?? 'light' ) === 'light' ) : ?>
												<option value="<?php echo esc_attr( $palette_id ); ?>" <?php selected( $settings['dark_light_toggle']['light_palette'] ?? 'professional-blue', $palette_id ); ?>>
													<?php echo esc_html( $palette['name'] ); ?>
												</option>
											<?php endif; ?>
										<?php endforeach; ?>
									</select>
									<p class="description">
										<?php esc_html_e( 'Color palette to use when light mode is active.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
							
							<!-- Dark Palette Selector (Requirement 10.4) -->
							<tr class="mase-conditional" data-depends-on="dark-mode-enabled">
								<th scope="row">
									<label for="dark-mode-dark-palette">
										<?php esc_html_e( 'Dark Mode Palette', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<select id="dark-mode-dark-palette" name="dark_light_toggle[dark_palette]" class="regular-text">
										<?php foreach ( $palettes as $palette_id => $palette ) : ?>
											<?php if ( ( $palette['type'] ?? 'light' ) === 'dark' ) : ?>
												<option value="<?php echo esc_attr( $palette_id ); ?>" <?php selected( $settings['dark_light_toggle']['dark_palette'] ?? 'dark-elegance', $palette_id ); ?>>
													<?php echo esc_html( $palette['name'] ); ?>
												</option>
											<?php endif; ?>
										<?php endforeach; ?>
									</select>
									<p class="description">
										<?php esc_html_e( 'Color palette to use when dark mode is active.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
							
							<!-- Transition Duration Slider (Requirement 10.5) -->
							<tr class="mase-conditional" data-depends-on="dark-mode-enabled">
								<th scope="row">
									<label for="dark-mode-transition-duration">
										<?php esc_html_e( 'Transition Duration', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<input 
										type="range" 
										id="dark-mode-transition-duration"
										name="dark_light_toggle[transition_duration]" 
										min="0"
										max="1000"
										step="50"
										value="<?php echo esc_attr( $settings['dark_light_toggle']['transition_duration'] ?? 300 ); ?>"
										aria-describedby="dark-mode-transition-duration-desc"
									/>
									<span class="mase-range-value"><?php echo esc_html( $settings['dark_light_toggle']['transition_duration'] ?? 300 ); ?>ms</span>
									<p class="description" id="dark-mode-transition-duration-desc">
										<?php esc_html_e( 'Animation duration when switching modes (0ms = instant, 1000ms = 1 second).', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
							
							<!-- Keyboard Shortcut Enable/Disable (Requirement 10.6) -->
							<tr class="mase-conditional" data-depends-on="dark-mode-enabled">
								<th scope="row">
									<label for="dark-mode-keyboard-shortcut">
										<?php esc_html_e( 'Keyboard Shortcut', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="dark-mode-keyboard-shortcut"
											name="dark_light_toggle[keyboard_shortcut_enabled]" 
											value="1"
											<?php checked( $settings['dark_light_toggle']['keyboard_shortcut_enabled'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['dark_light_toggle']['keyboard_shortcut_enabled'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="dark-mode-keyboard-shortcut-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="dark-mode-keyboard-shortcut-desc">
										<?php esc_html_e( 'Enable Ctrl+Shift+D (Windows/Linux) or Cmd+Shift+D (Mac) to toggle dark mode.', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
							
							<!-- FAB Position Controls (Requirement 10.7) -->
							<tr class="mase-conditional" data-depends-on="dark-mode-enabled">
								<th scope="row">
									<?php esc_html_e( 'FAB Position', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<div class="mase-settings-group">
										<div class="mase-setting-row">
											<label for="dark-mode-fab-bottom" class="mase-inline-label">
												<?php esc_html_e( 'Bottom:', 'modern-admin-styler' ); ?>
											</label>
											<input 
												type="number" 
												id="dark-mode-fab-bottom"
												name="dark_light_toggle[fab_position][bottom]" 
												class="small-text"
												value="<?php echo esc_attr( $settings['dark_light_toggle']['fab_position']['bottom'] ?? 20 ); ?>"
												min="0"
												max="200"
												step="5"
											/>
											<span class="mase-unit-label">px</span>
										</div>
										<div class="mase-setting-row">
											<label for="dark-mode-fab-right" class="mase-inline-label">
												<?php esc_html_e( 'Right:', 'modern-admin-styler' ); ?>
											</label>
											<input 
												type="number" 
												id="dark-mode-fab-right"
												name="dark_light_toggle[fab_position][right]" 
												class="small-text"
												value="<?php echo esc_attr( $settings['dark_light_toggle']['fab_position']['right'] ?? 20 ); ?>"
												min="0"
												max="200"
												step="5"
											/>
											<span class="mase-unit-label">px</span>
										</div>
									</div>
									<p class="description">
										<?php esc_html_e( 'Position of the floating action button from bottom-right corner (in pixels).', 'modern-admin-styler' ); ?>
									</p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Auto Palette Switching -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Auto Palette Switching', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Automatically switch color palettes based on time of day.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="advanced-auto-palette-switch">
										<?php esc_html_e( 'Enable Auto Switching', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="advanced-auto-palette-switch"
											name="advanced[auto_palette_switch]" 
											value="1"
											<?php checked( $settings['advanced']['auto_palette_switch'] ?? false, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['advanced']['auto_palette_switch'] ?? false ) ? 'true' : 'false'; ?>"
											aria-describedby="advanced-auto-palette-switch-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="advanced-auto-palette-switch-desc"><?php esc_html_e( 'Automatically change palettes based on time of day.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr class="mase-conditional" data-depends-on="advanced-auto-palette-switch">
								<th scope="row">
									<label for="auto-palette-morning">
										<?php esc_html_e( 'Morning (6:00-11:59)', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<select id="auto-palette-morning" name="advanced[auto_palette_times][morning]">
										<?php foreach ( $palettes as $palette_id => $palette ) : ?>
											<option value="<?php echo esc_attr( $palette_id ); ?>" <?php selected( $settings['advanced']['auto_palette_times']['morning'] ?? '', $palette_id ); ?>>
												<?php echo esc_html( $palette['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							
							<tr class="mase-conditional" data-depends-on="advanced-auto-palette-switch">
								<th scope="row">
									<label for="auto-palette-afternoon">
										<?php esc_html_e( 'Afternoon (12:00-17:59)', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<select id="auto-palette-afternoon" name="advanced[auto_palette_times][afternoon]">
										<?php foreach ( $palettes as $palette_id => $palette ) : ?>
											<option value="<?php echo esc_attr( $palette_id ); ?>" <?php selected( $settings['advanced']['auto_palette_times']['afternoon'] ?? '', $palette_id ); ?>>
												<?php echo esc_html( $palette['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							
							<tr class="mase-conditional" data-depends-on="advanced-auto-palette-switch">
								<th scope="row">
									<label for="auto-palette-evening">
										<?php esc_html_e( 'Evening (18:00-21:59)', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<select id="auto-palette-evening" name="advanced[auto_palette_times][evening]">
										<?php foreach ( $palettes as $palette_id => $palette ) : ?>
											<option value="<?php echo esc_attr( $palette_id ); ?>" <?php selected( $settings['advanced']['auto_palette_times']['evening'] ?? '', $palette_id ); ?>>
												<?php echo esc_html( $palette['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
							
							<tr class="mase-conditional" data-depends-on="advanced-auto-palette-switch">
								<th scope="row">
									<label for="auto-palette-night">
										<?php esc_html_e( 'Night (22:00-5:59)', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<select id="auto-palette-night" name="advanced[auto_palette_times][night]">
										<?php foreach ( $palettes as $palette_id => $palette ) : ?>
											<option value="<?php echo esc_attr( $palette_id ); ?>" <?php selected( $settings['advanced']['auto_palette_times']['night'] ?? '', $palette_id ); ?>>
												<?php echo esc_html( $palette['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Backup Controls -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Backup & Restore', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Manage backups of your settings.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<label for="advanced-backup-enabled">
										<?php esc_html_e( 'Enable Automatic Backups', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="advanced-backup-enabled"
											name="advanced[backup_enabled]" 
											value="1"
											<?php checked( $settings['advanced']['backup_enabled'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['advanced']['backup_enabled'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="advanced-backup-enabled-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="advanced-backup-enabled-desc"><?php esc_html_e( 'Automatically create backups before major changes.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<label for="advanced-backup-before-changes">
										<?php esc_html_e( 'Backup Before Changes', 'modern-admin-styler' ); ?>
									</label>
								</th>
								<td>
									<label class="mase-toggle-switch">
										<input 
											type="checkbox" 
											id="advanced-backup-before-changes"
											name="advanced[backup_before_changes]" 
											value="1"
											<?php checked( $settings['advanced']['backup_before_changes'] ?? true, true ); ?>
											role="switch"
											aria-checked="<?php echo ( $settings['advanced']['backup_before_changes'] ?? true ) ? 'true' : 'false'; ?>"
											aria-describedby="advanced-backup-before-changes-desc"
										/>
										<span class="mase-toggle-slider" aria-hidden="true"></span>
									</label>
									<p class="description" id="advanced-backup-before-changes-desc"><?php esc_html_e( 'Create backup before applying templates or importing settings.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<?php esc_html_e( 'Manual Backup', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<button type="button" id="mase-create-backup" class="button button-secondary">
										<span class="dashicons dashicons-backup"></span>
										<?php esc_html_e( 'Create Backup Now', 'modern-admin-styler' ); ?>
									</button>
									<p class="description"><?php esc_html_e( 'Manually create a backup of current settings.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<?php esc_html_e( 'Restore Backup', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<select id="mase-backup-list" class="regular-text">
										<option value=""><?php esc_html_e( 'Select a backup...', 'modern-admin-styler' ); ?></option>
										<!-- Backups will be populated via AJAX -->
									</select>
									<button type="button" id="mase-restore-backup" class="button button-secondary" disabled>
										<span class="dashicons dashicons-update"></span>
										<?php esc_html_e( 'Restore', 'modern-admin-styler' ); ?>
									</button>
									<p class="description"><?php esc_html_e( 'Restore settings from a previous backup.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				<!-- Import/Export -->
				<div class="mase-section">
					<div class="mase-section-header">
						<h2><?php esc_html_e( 'Import / Export', 'modern-admin-styler' ); ?></h2>
						<p class="description"><?php esc_html_e( 'Transfer settings between sites.', 'modern-admin-styler' ); ?></p>
					</div>
					
					<table class="form-table" role="presentation">
						<tbody>
							<tr>
								<th scope="row">
									<?php esc_html_e( 'Export Settings', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<button type="button" id="mase-export-settings" class="button button-secondary">
										<span class="dashicons dashicons-download"></span>
										<?php esc_html_e( 'Export to JSON', 'modern-admin-styler' ); ?>
									</button>
									<p class="description"><?php esc_html_e( 'Download all settings as a JSON file.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
							
							<tr>
								<th scope="row">
									<?php esc_html_e( 'Import Settings', 'modern-admin-styler' ); ?>
								</th>
								<td>
									<input type="file" id="mase-import-file" accept=".json" style="display: none;" />
									<button type="button" id="mase-import-settings" class="button button-secondary">
										<span class="dashicons dashicons-upload"></span>
										<?php esc_html_e( 'Import from JSON', 'modern-admin-styler' ); ?>
									</button>
									<p class="description"><?php esc_html_e( 'Import settings from a JSON file. This will overwrite current settings.', 'modern-admin-styler' ); ?></p>
								</td>
							</tr>
						</tbody>
					</table>
				</div>

				
			</div><!-- #tab-advanced -->

			<!-- ============================================ -->
			<!-- UNIVERSAL BUTTONS TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-buttons" data-tab-content="buttons" role="tabpanel" aria-labelledby="tab-button-buttons" tabindex="0">
				
				<!-- Button Type Selector Tabs (Subtask 5.2) -->
				<div class="mase-section">
					<div class="mase-button-type-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Button types', 'modern-admin-styler' ); ?>">
						<button type="button" class="mase-button-type-tab active" data-button-type="primary" role="tab" aria-selected="true" aria-controls="button-type-primary" tabindex="0">
							<?php esc_html_e( 'Primary', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-type-tab" data-button-type="secondary" role="tab" aria-selected="false" aria-controls="button-type-secondary" tabindex="-1">
							<?php esc_html_e( 'Secondary', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-type-tab" data-button-type="danger" role="tab" aria-selected="false" aria-controls="button-type-danger" tabindex="-1">
							<?php esc_html_e( 'Danger', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-type-tab" data-button-type="success" role="tab" aria-selected="false" aria-controls="button-type-success" tabindex="-1">
							<?php esc_html_e( 'Success', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-type-tab" data-button-type="ghost" role="tab" aria-selected="false" aria-controls="button-type-ghost" tabindex="-1">
							<?php esc_html_e( 'Ghost', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-type-tab" data-button-type="tabs" role="tab" aria-selected="false" aria-controls="button-type-tabs" tabindex="-1">
							<?php esc_html_e( 'Tabs', 'modern-admin-styler' ); ?>
						</button>
					</div>
				</div>

				<!-- Button State Selector Tabs (Subtask 5.3) -->
				<div class="mase-section">
					<div class="mase-button-state-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Button states', 'modern-admin-styler' ); ?>">
						<button type="button" class="mase-button-state-tab active" data-button-state="normal" role="tab" aria-selected="true" aria-controls="button-state-normal" tabindex="0">
							<?php esc_html_e( 'Normal', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-state-tab" data-button-state="hover" role="tab" aria-selected="false" aria-controls="button-state-hover" tabindex="-1">
							<?php esc_html_e( 'Hover', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-state-tab" data-button-state="active" role="tab" aria-selected="false" aria-controls="button-state-active" tabindex="-1">
							<?php esc_html_e( 'Active', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-state-tab" data-button-state="focus" role="tab" aria-selected="false" aria-controls="button-state-focus" tabindex="-1">
							<?php esc_html_e( 'Focus', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="mase-button-state-tab" data-button-state="disabled" role="tab" aria-selected="false" aria-controls="button-state-disabled" tabindex="-1">
							<?php esc_html_e( 'Disabled', 'modern-admin-styler' ); ?>
						</button>
					</div>
				</div>

				<!-- Button Controls Container -->
				<div class="mase-button-controls-wrapper">
					<div class="mase-button-controls-left">
						
						<!-- Background Controls Section (Subtask 5.4) -->
						<div class="mase-section">
							<div class="mase-section-card">
								<h3><?php esc_html_e( 'Background', 'modern-admin-styler' ); ?></h3>
								
								<div class="mase-settings-group">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-bg-type">
												<?php esc_html_e( 'Background Type', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<select id="button-bg-type" name="universal_buttons[primary][normal][bg_type]" class="mase-button-control" data-property="bg_type" data-button-type="primary" data-button-state="normal">
												<option value="solid"><?php esc_html_e( 'Solid Color', 'modern-admin-styler' ); ?></option>
												<option value="gradient"><?php esc_html_e( 'Gradient', 'modern-admin-styler' ); ?></option>
											</select>
										</div>
									</div>
									
									<!-- Solid Color Control -->
									<div class="mase-setting-row mase-conditional" data-depends-on="button-bg-type" data-value="solid">
										<div class="mase-setting-label">
											<label for="button-bg-color">
												<?php esc_html_e( 'Background Color', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="text" 
												id="button-bg-color"
												name="universal_buttons[primary][normal][bg_color]" 
												class="mase-color-picker mase-button-control"
												data-property="bg_color"
												data-button-type="primary"
												data-button-state="normal"
												value="#0073aa"
												data-default-color="#0073aa"
											/>
										</div>
									</div>
									
									<!-- Gradient Controls -->
									<div class="mase-conditional" data-depends-on="button-bg-type" data-value="gradient">
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-gradient-type">
													<?php esc_html_e( 'Gradient Type', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<select id="button-gradient-type" name="universal_buttons[primary][normal][gradient_type]" class="mase-button-control" data-property="gradient_type" data-button-type="primary" data-button-state="normal">
													<option value="linear"><?php esc_html_e( 'Linear', 'modern-admin-styler' ); ?></option>
													<option value="radial"><?php esc_html_e( 'Radial', 'modern-admin-styler' ); ?></option>
												</select>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-gradient-angle">
													<?php esc_html_e( 'Angle (degrees)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-gradient-angle"
													name="universal_buttons[primary][normal][gradient_angle]" 
													class="mase-button-control"
													data-property="gradient_angle"
													data-button-type="primary"
													data-button-state="normal"
													min="0"
													max="360"
													step="1"
													value="90"
												/>
												<span class="mase-range-value">90°</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-gradient-color-1">
													<?php esc_html_e( 'Color Stop 1', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="text" 
													id="button-gradient-color-1"
													name="universal_buttons[primary][normal][gradient_colors][0][color]" 
													class="mase-color-picker mase-button-control"
													data-property="gradient_colors_0_color"
													data-button-type="primary"
													data-button-state="normal"
													value="#0073aa"
													data-default-color="#0073aa"
												/>
												<input type="hidden" name="universal_buttons[primary][normal][gradient_colors][0][position]" value="0" data-button-type="primary" data-button-state="normal" />
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-gradient-color-2">
													<?php esc_html_e( 'Color Stop 2', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="text" 
													id="button-gradient-color-2"
													name="universal_buttons[primary][normal][gradient_colors][1][color]" 
													class="mase-color-picker mase-button-control"
													data-property="gradient_colors_1_color"
													data-button-type="primary"
													data-button-state="normal"
													value="#005177"
													data-default-color="#005177"
												/>
												<input type="hidden" name="universal_buttons[primary][normal][gradient_colors][1][position]" value="100" data-button-type="primary" data-button-state="normal" />
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Text Color Control (Subtask 5.5) -->
						<div class="mase-section">
							<div class="mase-section-card">
								<h3><?php esc_html_e( 'Text Color', 'modern-admin-styler' ); ?></h3>
								
								<div class="mase-settings-group">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-text-color">
												<?php esc_html_e( 'Text Color', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="text" 
												id="button-text-color"
												name="universal_buttons[primary][normal][text_color]" 
												class="mase-color-picker mase-button-control"
												data-property="text_color"
												data-button-type="primary"
												data-button-state="normal"
												value="#ffffff"
												data-default-color="#ffffff"
											/>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<?php esc_html_e( 'Contrast Ratio', 'modern-admin-styler' ); ?>
										</div>
										<div class="mase-setting-control">
											<div class="mase-contrast-indicator">
												<span class="mase-contrast-value" id="button-contrast-ratio">--</span>
												<span class="mase-contrast-status" id="button-contrast-status"></span>
											</div>
											<p class="description"><?php esc_html_e( 'WCAG AA requires 4.5:1 minimum', 'modern-admin-styler' ); ?></p>
										</div>
									</div>
								</div>
							</div>
						</div>

					</div><!-- .mase-button-controls-left -->
					
					<div class="mase-button-controls-right">
						
						<!-- Border Controls Section (Subtask 5.6) -->
						<div class="mase-section">
							<div class="mase-section-card">
								<h3><?php esc_html_e( 'Border', 'modern-admin-styler' ); ?></h3>
								
								<div class="mase-settings-group">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-border-width">
												<?php esc_html_e( 'Border Width (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="button-border-width"
												name="universal_buttons[primary][normal][border_width]" 
												class="mase-button-control"
												data-property="border_width"
												min="0"
												max="5"
												step="1"
												value="1"
											/>
											<span class="mase-range-value">1px</span>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-border-style">
												<?php esc_html_e( 'Border Style', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<select id="button-border-style" name="universal_buttons[primary][normal][border_style]" class="mase-button-control" data-property="border_style">
												<option value="solid"><?php esc_html_e( 'Solid', 'modern-admin-styler' ); ?></option>
												<option value="dashed"><?php esc_html_e( 'Dashed', 'modern-admin-styler' ); ?></option>
												<option value="dotted"><?php esc_html_e( 'Dotted', 'modern-admin-styler' ); ?></option>
												<option value="none"><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
											</select>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-border-color">
												<?php esc_html_e( 'Border Color', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="text" 
												id="button-border-color"
												name="universal_buttons[primary][normal][border_color]" 
												class="mase-color-picker mase-button-control"
												data-property="border_color"
												value="#0073aa"
												data-default-color="#0073aa"
											/>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-border-radius-mode">
												<?php esc_html_e( 'Border Radius Mode', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<select id="button-border-radius-mode" name="universal_buttons[primary][normal][border_radius_mode]" class="mase-button-control" data-property="border_radius_mode">
												<option value="uniform"><?php esc_html_e( 'Uniform', 'modern-admin-styler' ); ?></option>
												<option value="individual"><?php esc_html_e( 'Individual Corners', 'modern-admin-styler' ); ?></option>
											</select>
										</div>
									</div>
									
									<!-- Uniform Radius -->
									<div class="mase-setting-row mase-conditional" data-depends-on="button-border-radius-mode" data-value="uniform">
										<div class="mase-setting-label">
											<label for="button-border-radius">
												<?php esc_html_e( 'All Corners (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="button-border-radius"
												name="universal_buttons[primary][normal][border_radius]" 
												class="mase-button-control"
												data-property="border_radius"
												min="0"
												max="25"
												step="1"
												value="3"
											/>
											<span class="mase-range-value">3px</span>
										</div>
									</div>
									
									<!-- Individual Corners -->
									<div class="mase-conditional" data-depends-on="button-border-radius-mode" data-value="individual">
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-border-radius-tl">
													<?php esc_html_e( 'Top Left (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-border-radius-tl"
													name="universal_buttons[primary][normal][border_radius_tl]" 
													class="mase-button-control"
													data-property="border_radius_tl"
													min="0"
													max="25"
													step="1"
													value="3"
												/>
												<span class="mase-range-value">3px</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-border-radius-tr">
													<?php esc_html_e( 'Top Right (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-border-radius-tr"
													name="universal_buttons[primary][normal][border_radius_tr]" 
													class="mase-button-control"
													data-property="border_radius_tr"
													min="0"
													max="25"
													step="1"
													value="3"
												/>
												<span class="mase-range-value">3px</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-border-radius-bl">
													<?php esc_html_e( 'Bottom Left (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-border-radius-bl"
													name="universal_buttons[primary][normal][border_radius_bl]" 
													class="mase-button-control"
													data-property="border_radius_bl"
													min="0"
													max="25"
													step="1"
													value="3"
												/>
												<span class="mase-range-value">3px</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-border-radius-br">
													<?php esc_html_e( 'Bottom Right (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-border-radius-br"
													name="universal_buttons[primary][normal][border_radius_br]" 
													class="mase-button-control"
													data-property="border_radius_br"
													min="0"
													max="25"
													step="1"
													value="3"
												/>
												<span class="mase-range-value">3px</span>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Padding Controls Section (Subtask 5.7) -->
						<div class="mase-section">
							<div class="mase-section-card">
								<h3><?php esc_html_e( 'Padding', 'modern-admin-styler' ); ?></h3>
								
								<div class="mase-settings-group">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-padding-horizontal">
												<?php esc_html_e( 'Horizontal (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="button-padding-horizontal"
												name="universal_buttons[primary][normal][padding_horizontal]" 
												class="mase-button-control"
												data-property="padding_horizontal"
												min="5"
												max="30"
												step="1"
												value="12"
											/>
											<span class="mase-range-value">12px</span>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-padding-vertical">
												<?php esc_html_e( 'Vertical (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="button-padding-vertical"
												name="universal_buttons[primary][normal][padding_vertical]" 
												class="mase-button-control"
												data-property="padding_vertical"
												min="3"
												max="20"
												step="1"
												value="6"
											/>
											<span class="mase-range-value">6px</span>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Typography Controls Section (Subtask 5.8) -->
						<div class="mase-section">
							<div class="mase-section-card">
								<h3><?php esc_html_e( 'Typography', 'modern-admin-styler' ); ?></h3>
								
								<div class="mase-settings-group">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-font-size">
												<?php esc_html_e( 'Font Size (px)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="button-font-size"
												name="universal_buttons[primary][normal][font_size]" 
												class="mase-button-control"
												data-property="font_size"
												min="11"
												max="18"
												step="1"
												value="13"
											/>
											<span class="mase-range-value">13px</span>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-font-weight">
												<?php esc_html_e( 'Font Weight', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<select id="button-font-weight" name="universal_buttons[primary][normal][font_weight]" class="mase-button-control" data-property="font_weight">
												<option value="300">300 (Light)</option>
												<option value="400" selected>400 (Normal)</option>
												<option value="500">500 (Medium)</option>
												<option value="600">600 (Semi-Bold)</option>
												<option value="700">700 (Bold)</option>
											</select>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-text-transform">
												<?php esc_html_e( 'Text Transform', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<select id="button-text-transform" name="universal_buttons[primary][normal][text_transform]" class="mase-button-control" data-property="text_transform">
												<option value="none" selected><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
												<option value="uppercase"><?php esc_html_e( 'Uppercase', 'modern-admin-styler' ); ?></option>
												<option value="lowercase"><?php esc_html_e( 'Lowercase', 'modern-admin-styler' ); ?></option>
												<option value="capitalize"><?php esc_html_e( 'Capitalize', 'modern-admin-styler' ); ?></option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>

						<!-- Effects Controls Section (Subtask 5.9) -->
						<div class="mase-section">
							<div class="mase-section-card">
								<h3><?php esc_html_e( 'Effects', 'modern-admin-styler' ); ?></h3>
								
								<div class="mase-settings-group">
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-shadow-mode">
												<?php esc_html_e( 'Shadow Mode', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<select id="button-shadow-mode" name="universal_buttons[primary][normal][shadow_mode]" class="mase-button-control" data-property="shadow_mode">
												<option value="preset" selected><?php esc_html_e( 'Preset', 'modern-admin-styler' ); ?></option>
												<option value="custom"><?php esc_html_e( 'Custom', 'modern-admin-styler' ); ?></option>
												<option value="none"><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
											</select>
										</div>
									</div>
									
									<!-- Preset Shadow -->
									<div class="mase-setting-row mase-conditional" data-depends-on="button-shadow-mode" data-value="preset">
										<div class="mase-setting-label">
											<label for="button-shadow-preset">
												<?php esc_html_e( 'Shadow Preset', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<select id="button-shadow-preset" name="universal_buttons[primary][normal][shadow_preset]" class="mase-button-control" data-property="shadow_preset">
												<option value="none"><?php esc_html_e( 'None', 'modern-admin-styler' ); ?></option>
												<option value="subtle" selected><?php esc_html_e( 'Subtle', 'modern-admin-styler' ); ?></option>
												<option value="medium"><?php esc_html_e( 'Medium', 'modern-admin-styler' ); ?></option>
												<option value="strong"><?php esc_html_e( 'Strong', 'modern-admin-styler' ); ?></option>
											</select>
										</div>
									</div>
									
									<!-- Custom Shadow Controls -->
									<div class="mase-conditional" data-depends-on="button-shadow-mode" data-value="custom">
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-shadow-h-offset">
													<?php esc_html_e( 'Horizontal Offset (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-shadow-h-offset"
													name="universal_buttons[primary][normal][shadow_h_offset]" 
													class="mase-button-control"
													data-property="shadow_h_offset"
													min="-20"
													max="20"
													step="1"
													value="0"
												/>
												<span class="mase-range-value">0px</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-shadow-v-offset">
													<?php esc_html_e( 'Vertical Offset (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-shadow-v-offset"
													name="universal_buttons[primary][normal][shadow_v_offset]" 
													class="mase-button-control"
													data-property="shadow_v_offset"
													min="-20"
													max="20"
													step="1"
													value="2"
												/>
												<span class="mase-range-value">2px</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-shadow-blur">
													<?php esc_html_e( 'Blur Radius (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-shadow-blur"
													name="universal_buttons[primary][normal][shadow_blur]" 
													class="mase-button-control"
													data-property="shadow_blur"
													min="0"
													max="50"
													step="1"
													value="4"
												/>
												<span class="mase-range-value">4px</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-shadow-spread">
													<?php esc_html_e( 'Spread Radius (px)', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="range" 
													id="button-shadow-spread"
													name="universal_buttons[primary][normal][shadow_spread]" 
													class="mase-button-control"
													data-property="shadow_spread"
													min="-10"
													max="10"
													step="1"
													value="0"
												/>
												<span class="mase-range-value">0px</span>
											</div>
										</div>
										
										<div class="mase-setting-row">
											<div class="mase-setting-label">
												<label for="button-shadow-color">
													<?php esc_html_e( 'Shadow Color', 'modern-admin-styler' ); ?>
												</label>
											</div>
											<div class="mase-setting-control">
												<input 
													type="text" 
													id="button-shadow-color"
													name="universal_buttons[primary][normal][shadow_color]" 
													class="mase-color-picker mase-button-control"
													data-property="shadow_color"
													value="rgba(0,0,0,0.1)"
												/>
											</div>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-transition-duration">
												<?php esc_html_e( 'Transition Duration (ms)', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<input 
												type="range" 
												id="button-transition-duration"
												name="universal_buttons[primary][normal][transition_duration]" 
												class="mase-button-control"
												data-property="transition_duration"
												min="0"
												max="1000"
												step="50"
												value="200"
											/>
											<span class="mase-range-value">200ms</span>
										</div>
									</div>
									
									<div class="mase-setting-row">
										<div class="mase-setting-label">
											<label for="button-ripple-effect">
												<?php esc_html_e( 'Ripple Effect', 'modern-admin-styler' ); ?>
											</label>
										</div>
										<div class="mase-setting-control">
											<label class="mase-toggle-switch">
												<input 
													type="checkbox" 
													id="button-ripple-effect"
													name="universal_buttons[primary][normal][ripple_effect]" 
													class="mase-button-control"
													data-property="ripple_effect"
													value="1"
													role="switch"
													aria-checked="false"
												/>
												<span class="mase-toggle-slider" aria-hidden="true"></span>
											</label>
										</div>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div><!-- .mase-button-controls-wrapper -->

				<!-- Live Preview Area (Subtask 5.10) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h3><?php esc_html_e( 'Live Preview', 'modern-admin-styler' ); ?></h3>
						<p class="description"><?php esc_html_e( 'Preview your button styles in real-time across all states.', 'modern-admin-styler' ); ?></p>
						
						<div class="mase-button-preview-container">
							<!-- Normal State -->
							<div class="mase-button-preview-item">
								<label class="mase-button-preview-label"><?php esc_html_e( 'Normal', 'modern-admin-styler' ); ?></label>
								<button type="button" class="mase-button-preview" data-preview-state="normal" id="button-preview-normal">
									<?php esc_html_e( 'Sample Button', 'modern-admin-styler' ); ?>
								</button>
							</div>
							
							<!-- Hover State -->
							<div class="mase-button-preview-item">
								<label class="mase-button-preview-label"><?php esc_html_e( 'Hover', 'modern-admin-styler' ); ?></label>
								<button type="button" class="mase-button-preview mase-button-preview-hover" data-preview-state="hover" id="button-preview-hover">
									<?php esc_html_e( 'Sample Button', 'modern-admin-styler' ); ?>
								</button>
							</div>
							
							<!-- Active State -->
							<div class="mase-button-preview-item">
								<label class="mase-button-preview-label"><?php esc_html_e( 'Active', 'modern-admin-styler' ); ?></label>
								<button type="button" class="mase-button-preview mase-button-preview-active" data-preview-state="active" id="button-preview-active">
									<?php esc_html_e( 'Sample Button', 'modern-admin-styler' ); ?>
								</button>
							</div>
							
							<!-- Focus State -->
							<div class="mase-button-preview-item">
								<label class="mase-button-preview-label"><?php esc_html_e( 'Focus', 'modern-admin-styler' ); ?></label>
								<button type="button" class="mase-button-preview mase-button-preview-focus" data-preview-state="focus" id="button-preview-focus">
									<?php esc_html_e( 'Sample Button', 'modern-admin-styler' ); ?>
								</button>
							</div>
							
							<!-- Disabled State -->
							<div class="mase-button-preview-item">
								<label class="mase-button-preview-label"><?php esc_html_e( 'Disabled', 'modern-admin-styler' ); ?></label>
								<button type="button" class="mase-button-preview" data-preview-state="disabled" id="button-preview-disabled" disabled>
									<?php esc_html_e( 'Sample Button', 'modern-admin-styler' ); ?>
								</button>
							</div>
						</div>
					</div>
				</div>

				<!-- Reset Buttons (Subtask 5.11) -->
				<div class="mase-section">
					<div class="mase-button-reset-actions">
						<button type="button" class="button button-secondary mase-reset-button-type" id="reset-button-type">
							<span class="dashicons dashicons-image-rotate" aria-hidden="true"></span>
							<?php esc_html_e( 'Reset This Button Type', 'modern-admin-styler' ); ?>
						</button>
						<button type="button" class="button button-secondary mase-reset-all-buttons" id="reset-all-buttons">
							<span class="dashicons dashicons-update" aria-hidden="true"></span>
							<?php esc_html_e( 'Reset All Buttons', 'modern-admin-styler' ); ?>
						</button>
					</div>
				</div>

				<!-- Plugin Compatibility: Excluded Selectors (Subtask 8.2) -->
				<div class="mase-section">
					<div class="mase-section-card">
						<h3><?php esc_html_e( 'Plugin Compatibility', 'modern-admin-styler' ); ?></h3>
						<p class="description">
							<?php esc_html_e( 'Exclude specific button selectors from styling to prevent conflicts with other plugins.', 'modern-admin-styler' ); ?>
						</p>
						
						<div class="mase-settings-group">
							<div class="mase-setting-row">
								<div class="mase-setting-label">
									<label for="excluded-button-selectors">
										<?php esc_html_e( 'Excluded Selectors', 'modern-admin-styler' ); ?>
									</label>
								</div>
								<div class="mase-setting-control">
									<textarea 
										id="excluded-button-selectors"
										name="excluded_button_selectors"
										class="large-text code"
										rows="5"
										aria-describedby="excluded-selectors-description"
										placeholder=".my-plugin-button, #special-button, .custom-class"
									><?php echo esc_textarea( $settings['excluded_button_selectors'] ?? '' ); ?></textarea>
									<p class="description" id="excluded-selectors-description">
										<?php
										echo wp_kses(
											__( 'Enter CSS selectors (one per line or comma-separated) that should be excluded from button styling.<br><strong>Examples:</strong><br><code>.my-plugin-button</code> - Exclude by class<br><code>#special-button</code> - Exclude by ID<br><code>.button.custom-class</code> - Exclude specific combination<br><code>.wp-core-ui .my-button</code> - Exclude with parent selector', 'modern-admin-styler' ),
											array(
												'br'     => array(),
												'strong' => array(),
												'code'   => array(),
											)
										);
										?>
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>

				<!-- Button Controls Initialization Script (Task 10) -->
				<script type="text/javascript">
				jQuery(document).ready(function($) {
					// Initialize button controls with data attributes
					// This ensures all controls have proper data-button-type and data-button-state attributes
					var currentButtonType = 'primary';
					var currentButtonState = 'normal';
					
					// Function to update all button control attributes
					function updateButtonControlAttributes(buttonType, buttonState) {
						$('.mase-button-control').each(function() {
							var $control = $(this);
							var property = $control.data('property');
							
							// Update data attributes
							$control.attr('data-button-type', buttonType);
							$control.attr('data-button-state', buttonState);
							
							// Update name attribute
							var currentName = $control.attr('name');
							if (currentName && currentName.indexOf('universal_buttons[') === 0) {
								// Extract the property path from current name
								var matches = currentName.match(/universal_buttons\[([^\]]+)\]\[([^\]]+)\]\[(.+)\]/);
								if (matches && matches[3]) {
									var propertyPath = matches[3];
									var newName = 'universal_buttons[' + buttonType + '][' + buttonState + '][' + propertyPath + ']';
									$control.attr('name', newName);
								}
							}
						});
						
						// Update hidden inputs for gradient color positions
						$('input[type="hidden"][name*="gradient_colors"]').each(function() {
							var $hidden = $(this);
							var currentName = $hidden.attr('name');
							if (currentName && currentName.indexOf('universal_buttons[') === 0) {
								var matches = currentName.match(/universal_buttons\[([^\]]+)\]\[([^\]]+)\]\[(.+)\]/);
								if (matches && matches[3]) {
									var propertyPath = matches[3];
									var newName = 'universal_buttons[' + buttonType + '][' + buttonState + '][' + propertyPath + ']';
									$hidden.attr('name', newName);
									$hidden.attr('data-button-type', buttonType);
									$hidden.attr('data-button-state', buttonState);
								}
							}
						});
					}
					
					// Initialize on page load
					updateButtonControlAttributes(currentButtonType, currentButtonState);
					
					// Handle button type tab switching
					$('.mase-button-type-tab').on('click', function() {
						var $tab = $(this);
						var buttonType = $tab.data('button-type');
						
						// Update active state
						$('.mase-button-type-tab').removeClass('active').attr('aria-selected', 'false').attr('tabindex', '-1');
						$tab.addClass('active').attr('aria-selected', 'true').attr('tabindex', '0');
						
						// Update current button type
						currentButtonType = buttonType;
						
						// Update all control attributes
						updateButtonControlAttributes(currentButtonType, currentButtonState);
						
						// TODO: Load values from settings for this button type/state combination
						// This will be implemented in task 11
					});
					
					// Handle button state tab switching
					$('.mase-button-state-tab').on('click', function() {
						var $tab = $(this);
						var buttonState = $tab.data('button-state');
						
						// Update active state
						$('.mase-button-state-tab').removeClass('active').attr('aria-selected', 'false').attr('tabindex', '-1');
						$tab.addClass('active').attr('aria-selected', 'true').attr('tabindex', '0');
						
						// Update current button state
						currentButtonState = buttonState;
						
						// Update all control attributes
						updateButtonControlAttributes(currentButtonType, currentButtonState);
						
						// TODO: Load values from settings for this button type/state combination
						// This will be implemented in task 11
					});
					
					// Add keyboard navigation for button type tabs
					$('.mase-button-type-tab').on('keydown', function(e) {
						var $tabs = $('.mase-button-type-tab');
						var currentIndex = $tabs.index(this);
						var $target = null;
						
						if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
							e.preventDefault();
							$target = $tabs.eq((currentIndex + 1) % $tabs.length);
						} else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
							e.preventDefault();
							$target = $tabs.eq((currentIndex - 1 + $tabs.length) % $tabs.length);
						} else if (e.key === 'Home') {
							e.preventDefault();
							$target = $tabs.first();
						} else if (e.key === 'End') {
							e.preventDefault();
							$target = $tabs.last();
						}
						
						if ($target) {
							$target.focus().click();
						}
					});
					
					// Add keyboard navigation for button state tabs
					$('.mase-button-state-tab').on('keydown', function(e) {
						var $tabs = $('.mase-button-state-tab');
						var currentIndex = $tabs.index(this);
						var $target = null;
						
						if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
							e.preventDefault();
							$target = $tabs.eq((currentIndex + 1) % $tabs.length);
						} else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
							e.preventDefault();
							$target = $tabs.eq((currentIndex - 1 + $tabs.length) % $tabs.length);
						} else if (e.key === 'Home') {
							e.preventDefault();
							$target = $tabs.first();
						} else if (e.key === 'End') {
							e.preventDefault();
							$target = $tabs.last();
						}
						
						if ($target) {
							$target.focus().click();
						}
					});
				});
				</script>
				
			</div><!-- #tab-buttons -->

			<!-- ============================================ -->
			<!-- BACKGROUNDS TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-backgrounds" data-tab-content="backgrounds" role="tabpanel" aria-labelledby="tab-button-backgrounds" tabindex="0">
				<?php require_once MASE_PLUGIN_DIR . 'includes/backgrounds-tab-content.php'; ?>
			</div><!-- #tab-backgrounds -->

			<!-- ============================================ -->
			<!-- DASHBOARD WIDGETS TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-widgets" data-tab-content="widgets" role="tabpanel" aria-labelledby="tab-button-widgets" tabindex="0">
				<?php require_once MASE_PLUGIN_DIR . 'includes/widgets-tab-content.php'; ?>
			</div><!-- #tab-widgets -->

			<!-- ============================================ -->
			<!-- FORM CONTROLS TAB -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-form-controls" data-tab-content="form-controls" role="tabpanel" aria-labelledby="tab-button-form-controls" tabindex="0">
				<?php require_once MASE_PLUGIN_DIR . 'includes/form-controls-tab-content.php'; ?>
			</div><!-- #tab-form-controls -->

			<!-- ============================================ -->
			<!-- ADVANCED TAB -->
			<!-- Task 20: Theme Scheduling -->
			<!-- Requirements: 20.1, 20.2, 20.3, 20.4, 20.5 -->
			<!-- ============================================ -->
			<div class="mase-tab-content" id="tab-advanced" data-tab-content="advanced" role="tabpanel" aria-labelledby="tab-button-advanced" tabindex="0">
				
				<!-- Theme Scheduler Section (Requirement 20.1) -->
				<div class="mase-section">
					<div class="mase-scheduler-container">
						
						<!-- Scheduler Header (Requirement 20.1) -->
						<div class="mase-scheduler-header">
							<h2 class="mase-scheduler-title">
								<span class="dashicons dashicons-clock" aria-hidden="true"></span>
								<?php esc_html_e( 'Theme Scheduling', 'modern-admin-styler' ); ?>
							</h2>
							<div class="mase-scheduler-toggle">
								<label for="mase-scheduler-enabled">
									<input 
										type="checkbox" 
										id="mase-scheduler-enabled" 
										name="mase_scheduler[enabled]"
										value="1"
										<?php checked( $settings['scheduler']['enabled'] ?? false, true ); ?>
										aria-label="<?php esc_attr_e( 'Enable theme scheduling', 'modern-admin-styler' ); ?>"
									/>
									<?php esc_html_e( 'Enable Scheduling', 'modern-admin-styler' ); ?>
								</label>
							</div>
						</div>

						<p class="description" style="margin-bottom: 20px;">
							<?php esc_html_e( 'Automatically switch themes based on time of day. Perfect for matching your workflow or reducing eye strain.', 'modern-admin-styler' ); ?>
						</p>

						<!-- Timeline Visualization (Requirement 20.1) -->
						<div class="mase-scheduler-timeline" role="img" aria-label="<?php esc_attr_e( '24-hour timeline showing theme periods', 'modern-admin-styler' ); ?>">
							<div class="mase-timeline-overlay">
								<div class="mase-timeline-marker">
									<span class="dashicons dashicons-star-filled" aria-hidden="true"></span>
									<span><?php esc_html_e( 'Morning', 'modern-admin-styler' ); ?></span>
								</div>
								<div class="mase-timeline-marker">
									<span class="dashicons dashicons-admin-home" aria-hidden="true"></span>
									<span><?php esc_html_e( 'Afternoon', 'modern-admin-styler' ); ?></span>
								</div>
								<div class="mase-timeline-marker">
									<span class="dashicons dashicons-palmtree" aria-hidden="true"></span>
									<span><?php esc_html_e( 'Evening', 'modern-admin-styler' ); ?></span>
								</div>
								<div class="mase-timeline-marker">
									<span class="dashicons dashicons-moon" aria-hidden="true"></span>
									<span><?php esc_html_e( 'Night', 'modern-admin-styler' ); ?></span>
								</div>
							</div>
							<div class="mase-timeline-current" aria-hidden="true"></div>
						</div>

						<!-- Time Period Controls (Requirement 20.2) -->
						<div class="mase-scheduler-periods">
							
							<!-- Morning Period -->
							<div class="mase-period-card">
								<div class="mase-period-header">
									<div class="mase-period-icon" style="background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);">
										<span class="dashicons dashicons-star-filled" aria-hidden="true"></span>
									</div>
									<div class="mase-period-info">
										<h3 class="mase-period-name"><?php esc_html_e( 'Morning', 'modern-admin-styler' ); ?></h3>
										<p class="mase-period-time">06:00 - 12:00</p>
									</div>
								</div>
								<div class="mase-period-controls">
									<label for="mase-period-morning-theme">
										<?php esc_html_e( 'Theme', 'modern-admin-styler' ); ?>
									</label>
									<select 
										id="mase-period-morning-theme" 
										name="mase_scheduler[schedule][morning][theme]"
										class="mase-period-theme-select"
										data-period="morning"
										aria-label="<?php esc_attr_e( 'Select theme for morning period', 'modern-admin-styler' ); ?>"
									>
										<option value=""><?php esc_html_e( '-- No Theme --', 'modern-admin-styler' ); ?></option>
										<?php foreach ( $templates as $template_id => $template ) : ?>
											<option value="<?php echo esc_attr( $template_id ); ?>" <?php selected( $settings['scheduler']['schedule']['morning']['theme'] ?? '', $template_id ); ?>>
												<?php echo esc_html( $template['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>

							<!-- Afternoon Period -->
							<div class="mase-period-card">
								<div class="mase-period-header">
									<div class="mase-period-icon" style="background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);">
										<span class="dashicons dashicons-admin-home" aria-hidden="true"></span>
									</div>
									<div class="mase-period-info">
										<h3 class="mase-period-name"><?php esc_html_e( 'Afternoon', 'modern-admin-styler' ); ?></h3>
										<p class="mase-period-time">12:00 - 18:00</p>
									</div>
								</div>
								<div class="mase-period-controls">
									<label for="mase-period-afternoon-theme">
										<?php esc_html_e( 'Theme', 'modern-admin-styler' ); ?>
									</label>
									<select 
										id="mase-period-afternoon-theme" 
										name="mase_scheduler[schedule][afternoon][theme]"
										class="mase-period-theme-select"
										data-period="afternoon"
										aria-label="<?php esc_attr_e( 'Select theme for afternoon period', 'modern-admin-styler' ); ?>"
									>
										<option value=""><?php esc_html_e( '-- No Theme --', 'modern-admin-styler' ); ?></option>
										<?php foreach ( $templates as $template_id => $template ) : ?>
											<option value="<?php echo esc_attr( $template_id ); ?>" <?php selected( $settings['scheduler']['schedule']['afternoon']['theme'] ?? '', $template_id ); ?>>
												<?php echo esc_html( $template['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>

							<!-- Evening Period -->
							<div class="mase-period-card">
								<div class="mase-period-header">
									<div class="mase-period-icon" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">
										<span class="dashicons dashicons-palmtree" aria-hidden="true"></span>
									</div>
									<div class="mase-period-info">
										<h3 class="mase-period-name"><?php esc_html_e( 'Evening', 'modern-admin-styler' ); ?></h3>
										<p class="mase-period-time">18:00 - 22:00</p>
									</div>
								</div>
								<div class="mase-period-controls">
									<label for="mase-period-evening-theme">
										<?php esc_html_e( 'Theme', 'modern-admin-styler' ); ?>
									</label>
									<select 
										id="mase-period-evening-theme" 
										name="mase_scheduler[schedule][evening][theme]"
										class="mase-period-theme-select"
										data-period="evening"
										aria-label="<?php esc_attr_e( 'Select theme for evening period', 'modern-admin-styler' ); ?>"
									>
										<option value=""><?php esc_html_e( '-- No Theme --', 'modern-admin-styler' ); ?></option>
										<?php foreach ( $templates as $template_id => $template ) : ?>
											<option value="<?php echo esc_attr( $template_id ); ?>" <?php selected( $settings['scheduler']['schedule']['evening']['theme'] ?? '', $template_id ); ?>>
												<?php echo esc_html( $template['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>

							<!-- Night Period -->
							<div class="mase-period-card">
								<div class="mase-period-header">
									<div class="mase-period-icon" style="background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%);">
										<span class="dashicons dashicons-moon" aria-hidden="true"></span>
									</div>
									<div class="mase-period-info">
										<h3 class="mase-period-name"><?php esc_html_e( 'Night', 'modern-admin-styler' ); ?></h3>
										<p class="mase-period-time">22:00 - 06:00</p>
									</div>
								</div>
								<div class="mase-period-controls">
									<label for="mase-period-night-theme">
										<?php esc_html_e( 'Theme', 'modern-admin-styler' ); ?>
									</label>
									<select 
										id="mase-period-night-theme" 
										name="mase_scheduler[schedule][night][theme]"
										class="mase-period-theme-select"
										data-period="night"
										aria-label="<?php esc_attr_e( 'Select theme for night period', 'modern-admin-styler' ); ?>"
									>
										<option value=""><?php esc_html_e( '-- No Theme --', 'modern-admin-styler' ); ?></option>
										<?php foreach ( $templates as $template_id => $template ) : ?>
											<option value="<?php echo esc_attr( $template_id ); ?>" <?php selected( $settings['scheduler']['schedule']['night']['theme'] ?? '', $template_id ); ?>>
												<?php echo esc_html( $template['name'] ); ?>
											</option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>

						</div><!-- .mase-scheduler-periods -->

						<!-- System Sync Controls (Requirement 20.3) -->
						<div class="mase-scheduler-sync">
							<div class="mase-sync-header">
								<div class="mase-sync-icon">
									<span class="dashicons dashicons-update" aria-hidden="true"></span>
								</div>
								<div class="mase-sync-info">
									<h4><?php esc_html_e( 'Sync with System', 'modern-admin-styler' ); ?></h4>
									<p><?php esc_html_e( 'Automatically match your operating system\'s dark mode schedule', 'modern-admin-styler' ); ?></p>
								</div>
							</div>
							<div class="mase-sync-toggle">
								<input 
									type="checkbox" 
									id="mase-scheduler-sync-system" 
									name="mase_scheduler[sync_with_system]"
									value="1"
									<?php checked( $settings['scheduler']['sync_with_system'] ?? false, true ); ?>
									aria-describedby="mase-sync-description"
								/>
								<label for="mase-scheduler-sync-system">
									<?php esc_html_e( 'Enable system dark mode sync', 'modern-admin-styler' ); ?>
								</label>
							</div>
							<p id="mase-sync-description" class="description" style="margin-top: 8px; margin-left: 28px;">
								<?php esc_html_e( 'When enabled, themes will switch based on your system\'s light/dark mode preference instead of time periods.', 'modern-admin-styler' ); ?>
							</p>
						</div><!-- .mase-scheduler-sync -->

						<!-- Quick Actions -->
						<div class="mase-scheduler-actions">
							<button 
								type="button" 
								id="mase-save-scheduler" 
								class="button button-primary"
								aria-label="<?php esc_attr_e( 'Save scheduler settings', 'modern-admin-styler' ); ?>"
							>
								<span class="dashicons dashicons-saved" aria-hidden="true"></span>
								<span><?php esc_html_e( 'Save Schedule', 'modern-admin-styler' ); ?></span>
							</button>
							<button 
								type="button" 
								class="button button-secondary mase-scheduler-disable-btn"
								aria-label="<?php esc_attr_e( 'Quickly disable scheduler', 'modern-admin-styler' ); ?>"
							>
								<span class="dashicons dashicons-dismiss" aria-hidden="true"></span>
								<span><?php esc_html_e( 'Disable Schedule', 'modern-admin-styler' ); ?></span>
							</button>
						</div>

					</div><!-- .mase-scheduler-container -->
				</div><!-- .mase-section -->

			</div><!-- #tab-advanced -->
			
		</div><!-- .mase-tab-content-wrapper -->
		
	</form><!-- #mase-settings-form -->
	
	<!-- Notices Container -->
	<div id="mase-notices-container"></div>
	
	<!-- ============================================ -->
	<!-- TEMPLATE PREVIEW MODAL -->
	<!-- Task 2.1: Interactive Preview System -->
	<!-- Requirements: 1.1, 1.2, 1.3 -->
	<!-- ============================================ -->
	<div id="mase-preview-modal" class="mase-preview-modal" role="dialog" aria-modal="true" aria-labelledby="mase-preview-modal-title" aria-hidden="true" style="display: none;">
		<!-- Backdrop with blur effect (Requirement 1.1) -->
		<div class="mase-preview-backdrop" aria-hidden="true"></div>
		
		<!-- Modal Container (Requirement 1.2) -->
		<div class="mase-preview-container" role="document">
			<!-- Modal Header -->
			<div class="mase-preview-header">
				<h2 id="mase-preview-modal-title" class="mase-preview-title">
					<?php esc_html_e( 'Template Preview', 'modern-admin-styler' ); ?>
				</h2>
				<button 
					type="button" 
					class="mase-preview-close" 
					aria-label="<?php esc_attr_e( 'Close preview', 'modern-admin-styler' ); ?>"
					title="<?php esc_attr_e( 'Close (ESC)', 'modern-admin-styler' ); ?>"
				>
					<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
				</button>
			</div>
			
			<!-- Preview Content Area (Requirement 1.2) -->
			<div class="mase-preview-content">
				<!-- Loading State -->
				<div class="mase-preview-loading" role="status" aria-live="polite">
					<span class="dashicons dashicons-update mase-preview-spinner" aria-hidden="true"></span>
					<span class="mase-preview-loading-text"><?php esc_html_e( 'Loading preview...', 'modern-admin-styler' ); ?></span>
				</div>
				
				<!-- Preview Iframe (Requirement 1.2) -->
				<iframe 
					id="mase-preview-iframe" 
					class="mase-preview-iframe" 
					title="<?php esc_attr_e( 'Template preview', 'modern-admin-styler' ); ?>"
					sandbox="allow-same-origin allow-scripts"
					style="display: none;"
				></iframe>
			</div>
			
			<!-- Action Buttons (Requirement 1.3) -->
			<div class="mase-preview-actions">
				<button 
					type="button" 
					class="button button-secondary mase-preview-action-close"
					aria-label="<?php esc_attr_e( 'Close preview', 'modern-admin-styler' ); ?>"
				>
					<span class="dashicons dashicons-no" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Close', 'modern-admin-styler' ); ?></span>
				</button>
				
				<button 
					type="button" 
					class="button button-secondary mase-preview-action-customize"
					aria-label="<?php esc_attr_e( 'Customize template', 'modern-admin-styler' ); ?>"
					style="display: none;"
				>
					<span class="dashicons dashicons-admin-customizer" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Customize', 'modern-admin-styler' ); ?></span>
				</button>
				
				<button 
					type="button" 
					class="button button-primary mase-preview-action-apply"
					aria-label="<?php esc_attr_e( 'Apply template', 'modern-admin-styler' ); ?>"
				>
					<span class="dashicons dashicons-yes" aria-hidden="true"></span>
					<span><?php esc_html_e( 'Apply Template', 'modern-admin-styler' ); ?></span>
				</button>
			</div>
		</div>
	</div>
	
	<!-- Floating Action Button (FAB) - Requirements 25.1, 25.2 -->
	<button 
		type="button" 
		id="mase-fab-save" 
		class="mase-fab mase-fab-extended"
		aria-label="<?php esc_attr_e( 'Save all settings', 'modern-admin-styler' ); ?>"
		title="<?php esc_attr_e( 'Save Settings', 'modern-admin-styler' ); ?>"
	>
		<span class="mase-fab-icon dashicons dashicons-saved" aria-hidden="true"></span>
		<span class="mase-fab-label"><?php esc_html_e( 'Save', 'modern-admin-styler' ); ?></span>
	</button>
	
	<!-- Snackbar Notification System - Requirement 18.1 -->
	<div 
		id="mase-snackbar" 
		class="mase-snackbar" 
		role="status" 
		aria-live="polite" 
		aria-atomic="true"
		style="display: none;"
	>
		<div class="mase-snackbar-content">
			<span class="mase-snackbar-icon dashicons" aria-hidden="true"></span>
			<span class="mase-snackbar-message"></span>
		</div>
		<div class="mase-snackbar-actions">
			<button 
				type="button" 
				class="mase-snackbar-action" 
				style="display: none;"
			></button>
			<button 
				type="button" 
				class="mase-snackbar-close" 
				aria-label="<?php esc_attr_e( 'Close notification', 'modern-admin-styler' ); ?>"
			>
				<span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
			</button>
		</div>
	</div>
	
	<!-- MD3 Floating Action Button (Task 11: FAB) -->
	<button type="submit" 
		form="mase-settings-form" 
		class="mase-md3-fab" 
		id="mase-md3-save-fab"
		aria-label="<?php esc_attr_e( 'Save all settings', 'modern-admin-styler' ); ?>"
		title="<?php esc_attr_e( 'Save Settings', 'modern-admin-styler' ); ?>">
		<span class="mase-fab-icon dashicons dashicons-saved" aria-hidden="true"></span>
		<span class="mase-fab-label"><?php esc_html_e( 'Save', 'modern-admin-styler' ); ?></span>
		<span class="mase-ripple-container" aria-hidden="true"></span>
	</button>
	
	<!-- MD3 Snackbar Container (Task 12: Notification System) -->
	<div id="mase-md3-snackbar-container" 
		class="mase-md3-snackbar-container" 
		role="status" 
		aria-live="polite" 
		aria-atomic="true">
		<!-- Snackbars will be dynamically inserted here -->
	</div>
	
</div><!-- .wrap -->
